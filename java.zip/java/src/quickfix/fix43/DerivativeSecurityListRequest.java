package quickfix.fix43;

import quickfix.FieldNotFound;
import quickfix.Group;


public class DerivativeSecurityListRequest extends Message {
    static final long serialVersionUID = 20050617;
    public static final String MSGTYPE = "z";

    public DerivativeSecurityListRequest() {
        super();
        getHeader().setField(new quickfix.field.MsgType(MSGTYPE));
    }

    public DerivativeSecurityListRequest(
        quickfix.field.SecurityReqID securityReqID,
        quickfix.field.SecurityListRequestType securityListRequestType) {
        this();
        setField(securityReqID);
        setField(securityListRequestType);
    }

    public void set(quickfix.field.SecurityReqID value) {
        setField(value);
    }

    public quickfix.field.SecurityReqID get(quickfix.field.SecurityReqID value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.SecurityReqID getSecurityReqID()
        throws FieldNotFound {
        quickfix.field.SecurityReqID value = new quickfix.field.SecurityReqID();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.SecurityReqID field) {
        return isSetField(field);
    }

    public boolean isSetSecurityReqID() {
        return isSetField(320);
    }

    public void set(quickfix.field.SecurityListRequestType value) {
        setField(value);
    }

    public quickfix.field.SecurityListRequestType get(
        quickfix.field.SecurityListRequestType value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.SecurityListRequestType getSecurityListRequestType()
        throws FieldNotFound {
        quickfix.field.SecurityListRequestType value = new quickfix.field.SecurityListRequestType();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.SecurityListRequestType field) {
        return isSetField(field);
    }

    public boolean isSetSecurityListRequestType() {
        return isSetField(559);
    }

    public void set(quickfix.fix43.component.UnderlyingInstrument component) {
        setComponent(component);
    }

    public quickfix.fix43.component.UnderlyingInstrument get(
        quickfix.fix43.component.UnderlyingInstrument component)
        throws FieldNotFound {
        getComponent(component);

        return component;
    }

    public quickfix.fix43.component.UnderlyingInstrument getUnderlyingInstrument()
        throws FieldNotFound {
        quickfix.fix43.component.UnderlyingInstrument component = new quickfix.fix43.component.UnderlyingInstrument();
        getComponent(component);

        return component;
    }

    public void set(quickfix.field.UnderlyingSymbol value) {
        setField(value);
    }

    public quickfix.field.UnderlyingSymbol get(
        quickfix.field.UnderlyingSymbol value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.UnderlyingSymbol getUnderlyingSymbol()
        throws FieldNotFound {
        quickfix.field.UnderlyingSymbol value = new quickfix.field.UnderlyingSymbol();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.UnderlyingSymbol field) {
        return isSetField(field);
    }

    public boolean isSetUnderlyingSymbol() {
        return isSetField(311);
    }

    public void set(quickfix.field.UnderlyingSymbolSfx value) {
        setField(value);
    }

    public quickfix.field.UnderlyingSymbolSfx get(
        quickfix.field.UnderlyingSymbolSfx value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.UnderlyingSymbolSfx getUnderlyingSymbolSfx()
        throws FieldNotFound {
        quickfix.field.UnderlyingSymbolSfx value = new quickfix.field.UnderlyingSymbolSfx();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.UnderlyingSymbolSfx field) {
        return isSetField(field);
    }

    public boolean isSetUnderlyingSymbolSfx() {
        return isSetField(312);
    }

    public void set(quickfix.field.UnderlyingSecurityID value) {
        setField(value);
    }

    public quickfix.field.UnderlyingSecurityID get(
        quickfix.field.UnderlyingSecurityID value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.UnderlyingSecurityID getUnderlyingSecurityID()
        throws FieldNotFound {
        quickfix.field.UnderlyingSecurityID value = new quickfix.field.UnderlyingSecurityID();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.UnderlyingSecurityID field) {
        return isSetField(field);
    }

    public boolean isSetUnderlyingSecurityID() {
        return isSetField(309);
    }

    public void set(quickfix.field.UnderlyingSecurityIDSource value) {
        setField(value);
    }

    public quickfix.field.UnderlyingSecurityIDSource get(
        quickfix.field.UnderlyingSecurityIDSource value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.UnderlyingSecurityIDSource getUnderlyingSecurityIDSource()
        throws FieldNotFound {
        quickfix.field.UnderlyingSecurityIDSource value = new quickfix.field.UnderlyingSecurityIDSource();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.UnderlyingSecurityIDSource field) {
        return isSetField(field);
    }

    public boolean isSetUnderlyingSecurityIDSource() {
        return isSetField(305);
    }

    public void set(quickfix.field.NoUnderlyingSecurityAltID value) {
        setField(value);
    }

    public quickfix.field.NoUnderlyingSecurityAltID get(
        quickfix.field.NoUnderlyingSecurityAltID value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.NoUnderlyingSecurityAltID getNoUnderlyingSecurityAltID()
        throws FieldNotFound {
        quickfix.field.NoUnderlyingSecurityAltID value = new quickfix.field.NoUnderlyingSecurityAltID();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.NoUnderlyingSecurityAltID field) {
        return isSetField(field);
    }

    public boolean isSetNoUnderlyingSecurityAltID() {
        return isSetField(457);
    }

    public void set(quickfix.field.UnderlyingProduct value) {
        setField(value);
    }

    public quickfix.field.UnderlyingProduct get(
        quickfix.field.UnderlyingProduct value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.UnderlyingProduct getUnderlyingProduct()
        throws FieldNotFound {
        quickfix.field.UnderlyingProduct value = new quickfix.field.UnderlyingProduct();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.UnderlyingProduct field) {
        return isSetField(field);
    }

    public boolean isSetUnderlyingProduct() {
        return isSetField(462);
    }

    public void set(quickfix.field.UnderlyingCFICode value) {
        setField(value);
    }

    public quickfix.field.UnderlyingCFICode get(
        quickfix.field.UnderlyingCFICode value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.UnderlyingCFICode getUnderlyingCFICode()
        throws FieldNotFound {
        quickfix.field.UnderlyingCFICode value = new quickfix.field.UnderlyingCFICode();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.UnderlyingCFICode field) {
        return isSetField(field);
    }

    public boolean isSetUnderlyingCFICode() {
        return isSetField(463);
    }

    public void set(quickfix.field.UnderlyingSecurityType value) {
        setField(value);
    }

    public quickfix.field.UnderlyingSecurityType get(
        quickfix.field.UnderlyingSecurityType value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.UnderlyingSecurityType getUnderlyingSecurityType()
        throws FieldNotFound {
        quickfix.field.UnderlyingSecurityType value = new quickfix.field.UnderlyingSecurityType();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.UnderlyingSecurityType field) {
        return isSetField(field);
    }

    public boolean isSetUnderlyingSecurityType() {
        return isSetField(310);
    }

    public void set(quickfix.field.UnderlyingMaturityMonthYear value) {
        setField(value);
    }

    public quickfix.field.UnderlyingMaturityMonthYear get(
        quickfix.field.UnderlyingMaturityMonthYear value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.UnderlyingMaturityMonthYear getUnderlyingMaturityMonthYear()
        throws FieldNotFound {
        quickfix.field.UnderlyingMaturityMonthYear value = new quickfix.field.UnderlyingMaturityMonthYear();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.UnderlyingMaturityMonthYear field) {
        return isSetField(field);
    }

    public boolean isSetUnderlyingMaturityMonthYear() {
        return isSetField(313);
    }

    public void set(quickfix.field.UnderlyingMaturityDate value) {
        setField(value);
    }

    public quickfix.field.UnderlyingMaturityDate get(
        quickfix.field.UnderlyingMaturityDate value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.UnderlyingMaturityDate getUnderlyingMaturityDate()
        throws FieldNotFound {
        quickfix.field.UnderlyingMaturityDate value = new quickfix.field.UnderlyingMaturityDate();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.UnderlyingMaturityDate field) {
        return isSetField(field);
    }

    public boolean isSetUnderlyingMaturityDate() {
        return isSetField(542);
    }

    public void set(quickfix.field.UnderlyingCouponPaymentDate value) {
        setField(value);
    }

    public quickfix.field.UnderlyingCouponPaymentDate get(
        quickfix.field.UnderlyingCouponPaymentDate value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.UnderlyingCouponPaymentDate getUnderlyingCouponPaymentDate()
        throws FieldNotFound {
        quickfix.field.UnderlyingCouponPaymentDate value = new quickfix.field.UnderlyingCouponPaymentDate();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.UnderlyingCouponPaymentDate field) {
        return isSetField(field);
    }

    public boolean isSetUnderlyingCouponPaymentDate() {
        return isSetField(241);
    }

    public void set(quickfix.field.UnderlyingIssueDate value) {
        setField(value);
    }

    public quickfix.field.UnderlyingIssueDate get(
        quickfix.field.UnderlyingIssueDate value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.UnderlyingIssueDate getUnderlyingIssueDate()
        throws FieldNotFound {
        quickfix.field.UnderlyingIssueDate value = new quickfix.field.UnderlyingIssueDate();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.UnderlyingIssueDate field) {
        return isSetField(field);
    }

    public boolean isSetUnderlyingIssueDate() {
        return isSetField(242);
    }

    public void set(quickfix.field.UnderlyingRepoCollateralSecurityType value) {
        setField(value);
    }

    public quickfix.field.UnderlyingRepoCollateralSecurityType get(
        quickfix.field.UnderlyingRepoCollateralSecurityType value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.UnderlyingRepoCollateralSecurityType getUnderlyingRepoCollateralSecurityType()
        throws FieldNotFound {
        quickfix.field.UnderlyingRepoCollateralSecurityType value = new quickfix.field.UnderlyingRepoCollateralSecurityType();
        getField(value);

        return value;
    }

    public boolean isSet(
        quickfix.field.UnderlyingRepoCollateralSecurityType field) {
        return isSetField(field);
    }

    public boolean isSetUnderlyingRepoCollateralSecurityType() {
        return isSetField(243);
    }

    public void set(quickfix.field.UnderlyingRepurchaseTerm value) {
        setField(value);
    }

    public quickfix.field.UnderlyingRepurchaseTerm get(
        quickfix.field.UnderlyingRepurchaseTerm value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.UnderlyingRepurchaseTerm getUnderlyingRepurchaseTerm()
        throws FieldNotFound {
        quickfix.field.UnderlyingRepurchaseTerm value = new quickfix.field.UnderlyingRepurchaseTerm();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.UnderlyingRepurchaseTerm field) {
        return isSetField(field);
    }

    public boolean isSetUnderlyingRepurchaseTerm() {
        return isSetField(244);
    }

    public void set(quickfix.field.UnderlyingRepurchaseRate value) {
        setField(value);
    }

    public quickfix.field.UnderlyingRepurchaseRate get(
        quickfix.field.UnderlyingRepurchaseRate value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.UnderlyingRepurchaseRate getUnderlyingRepurchaseRate()
        throws FieldNotFound {
        quickfix.field.UnderlyingRepurchaseRate value = new quickfix.field.UnderlyingRepurchaseRate();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.UnderlyingRepurchaseRate field) {
        return isSetField(field);
    }

    public boolean isSetUnderlyingRepurchaseRate() {
        return isSetField(245);
    }

    public void set(quickfix.field.UnderlyingFactor value) {
        setField(value);
    }

    public quickfix.field.UnderlyingFactor get(
        quickfix.field.UnderlyingFactor value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.UnderlyingFactor getUnderlyingFactor()
        throws FieldNotFound {
        quickfix.field.UnderlyingFactor value = new quickfix.field.UnderlyingFactor();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.UnderlyingFactor field) {
        return isSetField(field);
    }

    public boolean isSetUnderlyingFactor() {
        return isSetField(246);
    }

    public void set(quickfix.field.UnderlyingCreditRating value) {
        setField(value);
    }

    public quickfix.field.UnderlyingCreditRating get(
        quickfix.field.UnderlyingCreditRating value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.UnderlyingCreditRating getUnderlyingCreditRating()
        throws FieldNotFound {
        quickfix.field.UnderlyingCreditRating value = new quickfix.field.UnderlyingCreditRating();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.UnderlyingCreditRating field) {
        return isSetField(field);
    }

    public boolean isSetUnderlyingCreditRating() {
        return isSetField(256);
    }

    public void set(quickfix.field.UnderlyingInstrRegistry value) {
        setField(value);
    }

    public quickfix.field.UnderlyingInstrRegistry get(
        quickfix.field.UnderlyingInstrRegistry value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.UnderlyingInstrRegistry getUnderlyingInstrRegistry()
        throws FieldNotFound {
        quickfix.field.UnderlyingInstrRegistry value = new quickfix.field.UnderlyingInstrRegistry();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.UnderlyingInstrRegistry field) {
        return isSetField(field);
    }

    public boolean isSetUnderlyingInstrRegistry() {
        return isSetField(595);
    }

    public void set(quickfix.field.UnderlyingCountryOfIssue value) {
        setField(value);
    }

    public quickfix.field.UnderlyingCountryOfIssue get(
        quickfix.field.UnderlyingCountryOfIssue value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.UnderlyingCountryOfIssue getUnderlyingCountryOfIssue()
        throws FieldNotFound {
        quickfix.field.UnderlyingCountryOfIssue value = new quickfix.field.UnderlyingCountryOfIssue();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.UnderlyingCountryOfIssue field) {
        return isSetField(field);
    }

    public boolean isSetUnderlyingCountryOfIssue() {
        return isSetField(592);
    }

    public void set(quickfix.field.UnderlyingStateOrProvinceOfIssue value) {
        setField(value);
    }

    public quickfix.field.UnderlyingStateOrProvinceOfIssue get(
        quickfix.field.UnderlyingStateOrProvinceOfIssue value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.UnderlyingStateOrProvinceOfIssue getUnderlyingStateOrProvinceOfIssue()
        throws FieldNotFound {
        quickfix.field.UnderlyingStateOrProvinceOfIssue value = new quickfix.field.UnderlyingStateOrProvinceOfIssue();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.UnderlyingStateOrProvinceOfIssue field) {
        return isSetField(field);
    }

    public boolean isSetUnderlyingStateOrProvinceOfIssue() {
        return isSetField(593);
    }

    public void set(quickfix.field.UnderlyingLocaleOfIssue value) {
        setField(value);
    }

    public quickfix.field.UnderlyingLocaleOfIssue get(
        quickfix.field.UnderlyingLocaleOfIssue value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.UnderlyingLocaleOfIssue getUnderlyingLocaleOfIssue()
        throws FieldNotFound {
        quickfix.field.UnderlyingLocaleOfIssue value = new quickfix.field.UnderlyingLocaleOfIssue();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.UnderlyingLocaleOfIssue field) {
        return isSetField(field);
    }

    public boolean isSetUnderlyingLocaleOfIssue() {
        return isSetField(594);
    }

    public void set(quickfix.field.UnderlyingRedemptionDate value) {
        setField(value);
    }

    public quickfix.field.UnderlyingRedemptionDate get(
        quickfix.field.UnderlyingRedemptionDate value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.UnderlyingRedemptionDate getUnderlyingRedemptionDate()
        throws FieldNotFound {
        quickfix.field.UnderlyingRedemptionDate value = new quickfix.field.UnderlyingRedemptionDate();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.UnderlyingRedemptionDate field) {
        return isSetField(field);
    }

    public boolean isSetUnderlyingRedemptionDate() {
        return isSetField(247);
    }

    public void set(quickfix.field.UnderlyingPutOrCall value) {
        setField(value);
    }

    public quickfix.field.UnderlyingPutOrCall get(
        quickfix.field.UnderlyingPutOrCall value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.UnderlyingPutOrCall getUnderlyingPutOrCall()
        throws FieldNotFound {
        quickfix.field.UnderlyingPutOrCall value = new quickfix.field.UnderlyingPutOrCall();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.UnderlyingPutOrCall field) {
        return isSetField(field);
    }

    public boolean isSetUnderlyingPutOrCall() {
        return isSetField(315);
    }

    public void set(quickfix.field.UnderlyingStrikePrice value) {
        setField(value);
    }

    public quickfix.field.UnderlyingStrikePrice get(
        quickfix.field.UnderlyingStrikePrice value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.UnderlyingStrikePrice getUnderlyingStrikePrice()
        throws FieldNotFound {
        quickfix.field.UnderlyingStrikePrice value = new quickfix.field.UnderlyingStrikePrice();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.UnderlyingStrikePrice field) {
        return isSetField(field);
    }

    public boolean isSetUnderlyingStrikePrice() {
        return isSetField(316);
    }

    public void set(quickfix.field.UnderlyingOptAttribute value) {
        setField(value);
    }

    public quickfix.field.UnderlyingOptAttribute get(
        quickfix.field.UnderlyingOptAttribute value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.UnderlyingOptAttribute getUnderlyingOptAttribute()
        throws FieldNotFound {
        quickfix.field.UnderlyingOptAttribute value = new quickfix.field.UnderlyingOptAttribute();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.UnderlyingOptAttribute field) {
        return isSetField(field);
    }

    public boolean isSetUnderlyingOptAttribute() {
        return isSetField(317);
    }

    public void set(quickfix.field.UnderlyingContractMultiplier value) {
        setField(value);
    }

    public quickfix.field.UnderlyingContractMultiplier get(
        quickfix.field.UnderlyingContractMultiplier value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.UnderlyingContractMultiplier getUnderlyingContractMultiplier()
        throws FieldNotFound {
        quickfix.field.UnderlyingContractMultiplier value = new quickfix.field.UnderlyingContractMultiplier();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.UnderlyingContractMultiplier field) {
        return isSetField(field);
    }

    public boolean isSetUnderlyingContractMultiplier() {
        return isSetField(436);
    }

    public void set(quickfix.field.UnderlyingCouponRate value) {
        setField(value);
    }

    public quickfix.field.UnderlyingCouponRate get(
        quickfix.field.UnderlyingCouponRate value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.UnderlyingCouponRate getUnderlyingCouponRate()
        throws FieldNotFound {
        quickfix.field.UnderlyingCouponRate value = new quickfix.field.UnderlyingCouponRate();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.UnderlyingCouponRate field) {
        return isSetField(field);
    }

    public boolean isSetUnderlyingCouponRate() {
        return isSetField(435);
    }

    public void set(quickfix.field.UnderlyingSecurityExchange value) {
        setField(value);
    }

    public quickfix.field.UnderlyingSecurityExchange get(
        quickfix.field.UnderlyingSecurityExchange value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.UnderlyingSecurityExchange getUnderlyingSecurityExchange()
        throws FieldNotFound {
        quickfix.field.UnderlyingSecurityExchange value = new quickfix.field.UnderlyingSecurityExchange();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.UnderlyingSecurityExchange field) {
        return isSetField(field);
    }

    public boolean isSetUnderlyingSecurityExchange() {
        return isSetField(308);
    }

    public void set(quickfix.field.UnderlyingIssuer value) {
        setField(value);
    }

    public quickfix.field.UnderlyingIssuer get(
        quickfix.field.UnderlyingIssuer value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.UnderlyingIssuer getUnderlyingIssuer()
        throws FieldNotFound {
        quickfix.field.UnderlyingIssuer value = new quickfix.field.UnderlyingIssuer();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.UnderlyingIssuer field) {
        return isSetField(field);
    }

    public boolean isSetUnderlyingIssuer() {
        return isSetField(306);
    }

    public void set(quickfix.field.EncodedUnderlyingIssuerLen value) {
        setField(value);
    }

    public quickfix.field.EncodedUnderlyingIssuerLen get(
        quickfix.field.EncodedUnderlyingIssuerLen value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.EncodedUnderlyingIssuerLen getEncodedUnderlyingIssuerLen()
        throws FieldNotFound {
        quickfix.field.EncodedUnderlyingIssuerLen value = new quickfix.field.EncodedUnderlyingIssuerLen();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.EncodedUnderlyingIssuerLen field) {
        return isSetField(field);
    }

    public boolean isSetEncodedUnderlyingIssuerLen() {
        return isSetField(362);
    }

    public void set(quickfix.field.EncodedUnderlyingIssuer value) {
        setField(value);
    }

    public quickfix.field.EncodedUnderlyingIssuer get(
        quickfix.field.EncodedUnderlyingIssuer value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.EncodedUnderlyingIssuer getEncodedUnderlyingIssuer()
        throws FieldNotFound {
        quickfix.field.EncodedUnderlyingIssuer value = new quickfix.field.EncodedUnderlyingIssuer();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.EncodedUnderlyingIssuer field) {
        return isSetField(field);
    }

    public boolean isSetEncodedUnderlyingIssuer() {
        return isSetField(363);
    }

    public void set(quickfix.field.UnderlyingSecurityDesc value) {
        setField(value);
    }

    public quickfix.field.UnderlyingSecurityDesc get(
        quickfix.field.UnderlyingSecurityDesc value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.UnderlyingSecurityDesc getUnderlyingSecurityDesc()
        throws FieldNotFound {
        quickfix.field.UnderlyingSecurityDesc value = new quickfix.field.UnderlyingSecurityDesc();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.UnderlyingSecurityDesc field) {
        return isSetField(field);
    }

    public boolean isSetUnderlyingSecurityDesc() {
        return isSetField(307);
    }

    public void set(quickfix.field.EncodedUnderlyingSecurityDescLen value) {
        setField(value);
    }

    public quickfix.field.EncodedUnderlyingSecurityDescLen get(
        quickfix.field.EncodedUnderlyingSecurityDescLen value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.EncodedUnderlyingSecurityDescLen getEncodedUnderlyingSecurityDescLen()
        throws FieldNotFound {
        quickfix.field.EncodedUnderlyingSecurityDescLen value = new quickfix.field.EncodedUnderlyingSecurityDescLen();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.EncodedUnderlyingSecurityDescLen field) {
        return isSetField(field);
    }

    public boolean isSetEncodedUnderlyingSecurityDescLen() {
        return isSetField(364);
    }

    public void set(quickfix.field.EncodedUnderlyingSecurityDesc value) {
        setField(value);
    }

    public quickfix.field.EncodedUnderlyingSecurityDesc get(
        quickfix.field.EncodedUnderlyingSecurityDesc value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.EncodedUnderlyingSecurityDesc getEncodedUnderlyingSecurityDesc()
        throws FieldNotFound {
        quickfix.field.EncodedUnderlyingSecurityDesc value = new quickfix.field.EncodedUnderlyingSecurityDesc();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.EncodedUnderlyingSecurityDesc field) {
        return isSetField(field);
    }

    public boolean isSetEncodedUnderlyingSecurityDesc() {
        return isSetField(365);
    }

    public void set(quickfix.field.Currency value) {
        setField(value);
    }

    public quickfix.field.Currency get(quickfix.field.Currency value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.Currency getCurrency() throws FieldNotFound {
        quickfix.field.Currency value = new quickfix.field.Currency();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.Currency field) {
        return isSetField(field);
    }

    public boolean isSetCurrency() {
        return isSetField(15);
    }

    public void set(quickfix.field.Text value) {
        setField(value);
    }

    public quickfix.field.Text get(quickfix.field.Text value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.Text getText() throws FieldNotFound {
        quickfix.field.Text value = new quickfix.field.Text();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.Text field) {
        return isSetField(field);
    }

    public boolean isSetText() {
        return isSetField(58);
    }

    public void set(quickfix.field.EncodedTextLen value) {
        setField(value);
    }

    public quickfix.field.EncodedTextLen get(
        quickfix.field.EncodedTextLen value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.EncodedTextLen getEncodedTextLen()
        throws FieldNotFound {
        quickfix.field.EncodedTextLen value = new quickfix.field.EncodedTextLen();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.EncodedTextLen field) {
        return isSetField(field);
    }

    public boolean isSetEncodedTextLen() {
        return isSetField(354);
    }

    public void set(quickfix.field.EncodedText value) {
        setField(value);
    }

    public quickfix.field.EncodedText get(quickfix.field.EncodedText value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.EncodedText getEncodedText()
        throws FieldNotFound {
        quickfix.field.EncodedText value = new quickfix.field.EncodedText();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.EncodedText field) {
        return isSetField(field);
    }

    public boolean isSetEncodedText() {
        return isSetField(355);
    }

    public void set(quickfix.field.TradingSessionID value) {
        setField(value);
    }

    public quickfix.field.TradingSessionID get(
        quickfix.field.TradingSessionID value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.TradingSessionID getTradingSessionID()
        throws FieldNotFound {
        quickfix.field.TradingSessionID value = new quickfix.field.TradingSessionID();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.TradingSessionID field) {
        return isSetField(field);
    }

    public boolean isSetTradingSessionID() {
        return isSetField(336);
    }

    public void set(quickfix.field.TradingSessionSubID value) {
        setField(value);
    }

    public quickfix.field.TradingSessionSubID get(
        quickfix.field.TradingSessionSubID value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.TradingSessionSubID getTradingSessionSubID()
        throws FieldNotFound {
        quickfix.field.TradingSessionSubID value = new quickfix.field.TradingSessionSubID();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.TradingSessionSubID field) {
        return isSetField(field);
    }

    public boolean isSetTradingSessionSubID() {
        return isSetField(625);
    }

    public void set(quickfix.field.SubscriptionRequestType value) {
        setField(value);
    }

    public quickfix.field.SubscriptionRequestType get(
        quickfix.field.SubscriptionRequestType value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.SubscriptionRequestType getSubscriptionRequestType()
        throws FieldNotFound {
        quickfix.field.SubscriptionRequestType value = new quickfix.field.SubscriptionRequestType();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.SubscriptionRequestType field) {
        return isSetField(field);
    }

    public boolean isSetSubscriptionRequestType() {
        return isSetField(263);
    }

    public static class NoUnderlyingSecurityAltID extends Group {
        static final long serialVersionUID = 20050617;

        public NoUnderlyingSecurityAltID() {
            super(457, 458, new int[] { 458, 459, 0 });
        }

        public void set(quickfix.field.UnderlyingSecurityAltID value) {
            setField(value);
        }

        public quickfix.field.UnderlyingSecurityAltID get(
            quickfix.field.UnderlyingSecurityAltID value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.UnderlyingSecurityAltID getUnderlyingSecurityAltID()
            throws FieldNotFound {
            quickfix.field.UnderlyingSecurityAltID value = new quickfix.field.UnderlyingSecurityAltID();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.UnderlyingSecurityAltID field) {
            return isSetField(field);
        }

        public boolean isSetUnderlyingSecurityAltID() {
            return isSetField(458);
        }

        public void set(quickfix.field.UnderlyingSecurityAltIDSource value) {
            setField(value);
        }

        public quickfix.field.UnderlyingSecurityAltIDSource get(
            quickfix.field.UnderlyingSecurityAltIDSource value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.UnderlyingSecurityAltIDSource getUnderlyingSecurityAltIDSource()
            throws FieldNotFound {
            quickfix.field.UnderlyingSecurityAltIDSource value = new quickfix.field.UnderlyingSecurityAltIDSource();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.UnderlyingSecurityAltIDSource field) {
            return isSetField(field);
        }

        public boolean isSetUnderlyingSecurityAltIDSource() {
            return isSetField(459);
        }
    }
}
