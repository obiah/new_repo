package quickfix.fix43;

import quickfix.FieldNotFound;
import quickfix.Group;


public class AllocationACK extends Message {
    static final long serialVersionUID = 20050617;
    public static final String MSGTYPE = "P";

    public AllocationACK() {
        super();
        getHeader().setField(new quickfix.field.MsgType(MSGTYPE));
    }

    public AllocationACK(quickfix.field.AllocID allocID,
        quickfix.field.TradeDate tradeDate,
        quickfix.field.AllocStatus allocStatus) {
        this();
        setField(allocID);
        setField(tradeDate);
        setField(allocStatus);
    }

    public void set(quickfix.fix43.component.Parties component) {
        setComponent(component);
    }

    public quickfix.fix43.component.Parties get(
        quickfix.fix43.component.Parties component) throws FieldNotFound {
        getComponent(component);

        return component;
    }

    public quickfix.fix43.component.Parties getParties()
        throws FieldNotFound {
        quickfix.fix43.component.Parties component = new quickfix.fix43.component.Parties();
        getComponent(component);

        return component;
    }

    public void set(quickfix.field.NoPartyIDs value) {
        setField(value);
    }

    public quickfix.field.NoPartyIDs get(quickfix.field.NoPartyIDs value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.NoPartyIDs getNoPartyIDs() throws FieldNotFound {
        quickfix.field.NoPartyIDs value = new quickfix.field.NoPartyIDs();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.NoPartyIDs field) {
        return isSetField(field);
    }

    public boolean isSetNoPartyIDs() {
        return isSetField(453);
    }

    public void set(quickfix.field.AllocID value) {
        setField(value);
    }

    public quickfix.field.AllocID get(quickfix.field.AllocID value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.AllocID getAllocID() throws FieldNotFound {
        quickfix.field.AllocID value = new quickfix.field.AllocID();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.AllocID field) {
        return isSetField(field);
    }

    public boolean isSetAllocID() {
        return isSetField(70);
    }

    public void set(quickfix.field.TradeDate value) {
        setField(value);
    }

    public quickfix.field.TradeDate get(quickfix.field.TradeDate value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.TradeDate getTradeDate() throws FieldNotFound {
        quickfix.field.TradeDate value = new quickfix.field.TradeDate();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.TradeDate field) {
        return isSetField(field);
    }

    public boolean isSetTradeDate() {
        return isSetField(75);
    }

    public void set(quickfix.field.TransactTime value) {
        setField(value);
    }

    public quickfix.field.TransactTime get(quickfix.field.TransactTime value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.TransactTime getTransactTime()
        throws FieldNotFound {
        quickfix.field.TransactTime value = new quickfix.field.TransactTime();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.TransactTime field) {
        return isSetField(field);
    }

    public boolean isSetTransactTime() {
        return isSetField(60);
    }

    public void set(quickfix.field.AllocStatus value) {
        setField(value);
    }

    public quickfix.field.AllocStatus get(quickfix.field.AllocStatus value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.AllocStatus getAllocStatus()
        throws FieldNotFound {
        quickfix.field.AllocStatus value = new quickfix.field.AllocStatus();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.AllocStatus field) {
        return isSetField(field);
    }

    public boolean isSetAllocStatus() {
        return isSetField(87);
    }

    public void set(quickfix.field.AllocRejCode value) {
        setField(value);
    }

    public quickfix.field.AllocRejCode get(quickfix.field.AllocRejCode value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.AllocRejCode getAllocRejCode()
        throws FieldNotFound {
        quickfix.field.AllocRejCode value = new quickfix.field.AllocRejCode();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.AllocRejCode field) {
        return isSetField(field);
    }

    public boolean isSetAllocRejCode() {
        return isSetField(88);
    }

    public void set(quickfix.field.Text value) {
        setField(value);
    }

    public quickfix.field.Text get(quickfix.field.Text value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.Text getText() throws FieldNotFound {
        quickfix.field.Text value = new quickfix.field.Text();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.Text field) {
        return isSetField(field);
    }

    public boolean isSetText() {
        return isSetField(58);
    }

    public void set(quickfix.field.EncodedTextLen value) {
        setField(value);
    }

    public quickfix.field.EncodedTextLen get(
        quickfix.field.EncodedTextLen value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.EncodedTextLen getEncodedTextLen()
        throws FieldNotFound {
        quickfix.field.EncodedTextLen value = new quickfix.field.EncodedTextLen();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.EncodedTextLen field) {
        return isSetField(field);
    }

    public boolean isSetEncodedTextLen() {
        return isSetField(354);
    }

    public void set(quickfix.field.EncodedText value) {
        setField(value);
    }

    public quickfix.field.EncodedText get(quickfix.field.EncodedText value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.EncodedText getEncodedText()
        throws FieldNotFound {
        quickfix.field.EncodedText value = new quickfix.field.EncodedText();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.EncodedText field) {
        return isSetField(field);
    }

    public boolean isSetEncodedText() {
        return isSetField(355);
    }

    public void set(quickfix.field.LegalConfirm value) {
        setField(value);
    }

    public quickfix.field.LegalConfirm get(quickfix.field.LegalConfirm value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.LegalConfirm getLegalConfirm()
        throws FieldNotFound {
        quickfix.field.LegalConfirm value = new quickfix.field.LegalConfirm();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.LegalConfirm field) {
        return isSetField(field);
    }

    public boolean isSetLegalConfirm() {
        return isSetField(650);
    }

    public static class NoPartyIDs extends Group {
        static final long serialVersionUID = 20050617;

        public NoPartyIDs() {
            super(453, 448, new int[] { 448, 447, 452, 523, 0 });
        }

        public void set(quickfix.field.PartyID value) {
            setField(value);
        }

        public quickfix.field.PartyID get(quickfix.field.PartyID value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.PartyID getPartyID() throws FieldNotFound {
            quickfix.field.PartyID value = new quickfix.field.PartyID();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.PartyID field) {
            return isSetField(field);
        }

        public boolean isSetPartyID() {
            return isSetField(448);
        }

        public void set(quickfix.field.PartyIDSource value) {
            setField(value);
        }

        public quickfix.field.PartyIDSource get(
            quickfix.field.PartyIDSource value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.PartyIDSource getPartyIDSource()
            throws FieldNotFound {
            quickfix.field.PartyIDSource value = new quickfix.field.PartyIDSource();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.PartyIDSource field) {
            return isSetField(field);
        }

        public boolean isSetPartyIDSource() {
            return isSetField(447);
        }

        public void set(quickfix.field.PartyRole value) {
            setField(value);
        }

        public quickfix.field.PartyRole get(quickfix.field.PartyRole value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.PartyRole getPartyRole()
            throws FieldNotFound {
            quickfix.field.PartyRole value = new quickfix.field.PartyRole();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.PartyRole field) {
            return isSetField(field);
        }

        public boolean isSetPartyRole() {
            return isSetField(452);
        }

        public void set(quickfix.field.PartySubID value) {
            setField(value);
        }

        public quickfix.field.PartySubID get(quickfix.field.PartySubID value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.PartySubID getPartySubID()
            throws FieldNotFound {
            quickfix.field.PartySubID value = new quickfix.field.PartySubID();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.PartySubID field) {
            return isSetField(field);
        }

        public boolean isSetPartySubID() {
            return isSetField(523);
        }
    }
}
