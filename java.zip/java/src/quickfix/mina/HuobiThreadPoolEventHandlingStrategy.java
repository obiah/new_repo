package quickfix.mina;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;

import quickfix.Message;
import quickfix.Session;

public class HuobiThreadPoolEventHandlingStrategy implements
		EventHandlingStrategy {

	private final SessionConnector sessionConnector;
	ExecutorService pool = Executors.newFixedThreadPool(20);
	// private final BlockingQueue<Message> messages = new
	// LinkedBlockingQueue<Message>();
	private final BlockingQueue<ConcurrentHashMap<Session, Message>> queue = new LinkedBlockingQueue<ConcurrentHashMap<Session, Message>>();

	public HuobiThreadPoolEventHandlingStrategy(SessionConnector connector) {
		sessionConnector = connector;

	}

	@Override
	public void onMessage(final Session quickfixSession, final Message message) {
		try {
			queue.put(new ConcurrentHashMap<Session, Message>() {
				{
					put(quickfixSession, message);
				}
			});

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void stopDispatcherThreads() {
	}

	@Override
	public SessionConnector getSessionConnector() {
		return sessionConnector;
	}

	@Override
	public int getQueueSize() {
		return 0;
	}

}