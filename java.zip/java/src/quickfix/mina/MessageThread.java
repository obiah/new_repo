package quickfix.mina;

import quickfix.LogUtil;
import quickfix.Message;
import quickfix.Session;

public class MessageThread extends Thread {
	private Session quickfixSession;
	private Message message;

	public MessageThread(Session quickfixSession, Message message) {
		super();
		this.quickfixSession = quickfixSession;
		this.message = message;
	}

	private volatile boolean stopped;
	private volatile boolean stopping;

	public Message getMessage() {
		return message;
	}

	public void setMessage(Message message) {
		this.message = message;
	}

	public Session getQuickfixSession() {
		return quickfixSession;
	}

	public void setQuickfixSession(Session quickfixSession) {
		this.quickfixSession = quickfixSession;
	}

	public MessageThread(Session session) {
		super("QF/J Session dispatcher: " + session.getSessionID());
		quickfixSession = session;
	}

	public MessageThread() {

	}

	@Override
	public void run() {
		while (!stopping) {
			try {
				if (quickfixSession.hasResponder() && message != null) {
					quickfixSession.next(message);
				} else {
					stopping = true;
				}
			} catch (final Throwable e) {
				stopping = true;
				LogUtil.logThrowable(quickfixSession.getSessionID(),
						"Error during message processing", e);
			}
		}
		stopped = true;
	}

	public void stopThread() {
		stopping = true;
		stopped = true;
	}

	public boolean isStopped() {
		return stopped;
	}
}
