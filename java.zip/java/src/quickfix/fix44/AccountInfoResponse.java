package quickfix.fix44;

import quickfix.FieldNotFound;

public class AccountInfoResponse extends Message {

	private static final long serialVersionUID = -5175480789342057696L;
	public static final String MSGTYPE = "Z1001";

	public AccountInfoResponse() {
		super();
		getHeader().setField(new quickfix.field.MsgType(MSGTYPE));
	}

	public void set(quickfix.field.Account value) {
		setField(value);
	}

	public quickfix.field.Account get(quickfix.field.Account value)
			throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.Account getAccount() throws FieldNotFound {
		quickfix.field.Account value = new quickfix.field.Account();
		getField(value);
		return value;
	}

	public boolean isSet(quickfix.field.Account field) {
		return isSetField(field);
	}

	public boolean isSetAccount() {
		return isSetField(1);
	}

	public void set(quickfix.field.AccReqID value) {
		setField(value);
	}

	public quickfix.field.AccReqID get(quickfix.field.AccReqID value)
			throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.AccReqID getAccReqID() throws FieldNotFound {
		quickfix.field.AccReqID value = new quickfix.field.AccReqID();
		getField(value);
		return value;
	}

	public boolean isSet(quickfix.field.AccReqID field) {
		return isSetField(field);
	}

	public boolean isSetAccReqID() {
		return isSetField(1622);
	}

	public void set(quickfix.field.AvailableCny value) {
		setField(value);
	}

	public quickfix.field.AvailableCny get(quickfix.field.AvailableCny value)
			throws FieldNotFound {
		getField(value);

		return value;
	}

	public quickfix.field.AvailableCny getAvailableCny() throws FieldNotFound {
		quickfix.field.AvailableCny value = new quickfix.field.AvailableCny();
		getField(value);

		return value;
	}

	public boolean isSet(quickfix.field.AvailableCny field) {
		return isSetField(field);
	}

	public boolean isSetAvailableCny() {
		return isSetField(1623);
	}

	public void set(quickfix.field.AvailableBtc value) {
		setField(value);
	}

	public quickfix.field.AvailableBtc get(quickfix.field.AvailableBtc value)
			throws FieldNotFound {
		getField(value);

		return value;
	}

	public quickfix.field.AvailableBtc getAvailableBtc() throws FieldNotFound {
		quickfix.field.AvailableBtc value = new quickfix.field.AvailableBtc();
		getField(value);

		return value;
	}

	public boolean isSet(quickfix.field.AvailableBtc field) {
		return isSetField(field);
	}

	public boolean isSetAvailableBtc() {
		return isSetField(1624);
	}

	public void set(quickfix.field.AvailableLtc value) {
		setField(value);
	}

	public quickfix.field.AvailableLtc get(quickfix.field.AvailableLtc value)
			throws FieldNotFound {
		getField(value);

		return value;
	}

	public quickfix.field.AvailableLtc getAvailableLtc() throws FieldNotFound {
		quickfix.field.AvailableLtc value = new quickfix.field.AvailableLtc();
		getField(value);

		return value;
	}

	public boolean isSet(quickfix.field.AvailableLtc field) {
		return isSetField(field);
	}

	public boolean isSetAvailableLtc() {
		return isSetField(1625);
	}
	
	public void set(quickfix.field.FrozenLtc value) {
        setField(value);
    }

    public quickfix.field.FrozenLtc get(quickfix.field.FrozenLtc value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.FrozenLtc getFrozenLtc() throws FieldNotFound {
        quickfix.field.FrozenLtc value = new quickfix.field.FrozenLtc();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.FrozenLtc field) {
        return isSetField(field);
    }

    public boolean isSetFrozenLtc() {
        return isSetField(1626);
    }
    
    public void set(quickfix.field.FrozenBtc value) {
        setField(value);
    }

    public quickfix.field.FrozenBtc get(quickfix.field.FrozenBtc value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.FrozenBtc getFrozenBtc() throws FieldNotFound {
        quickfix.field.FrozenBtc value = new quickfix.field.FrozenBtc();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.FrozenBtc field) {
        return isSetField(field);
    }

    public boolean isSetFrozenBtc() {
        return isSetField(1627);
    }
    
    public void set(quickfix.field.FrozenCny value) {
        setField(value);
    }

    public quickfix.field.FrozenCny get(quickfix.field.FrozenCny value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.FrozenCny getFrozenCny() throws FieldNotFound {
        quickfix.field.FrozenCny value = new quickfix.field.FrozenCny();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.FrozenCny field) {
        return isSetField(field);
    }

    public boolean isSetFrozenCny() {
        return isSetField(1628);
    }

    public void set(quickfix.field.LoanCny value) {
        setField(value);
    }

    public quickfix.field.LoanCny get(quickfix.field.LoanCny value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.LoanCny getLoanCny() throws FieldNotFound {
        quickfix.field.LoanCny value = new quickfix.field.LoanCny();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.LoanCny field) {
        return isSetField(field);
    }

    public boolean isSetLoanCny() {
        return isSetField(1628);
    }
    
    public void set(quickfix.field.LoanBtc value) {
        setField(value);
    }

    public quickfix.field.LoanBtc get(quickfix.field.LoanBtc value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.LoanBtc getLoanBtc() throws FieldNotFound {
        quickfix.field.LoanBtc value = new quickfix.field.LoanBtc();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.LoanBtc field) {
        return isSetField(field);
    }

    public boolean isSetLoanBtc() {
        return isSetField(1628);
    }
    
    public void set(quickfix.field.LoanLtc value) {
        setField(value);
    }

    public quickfix.field.LoanLtc get(quickfix.field.LoanLtc value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.LoanLtc getLoanLtc() throws FieldNotFound {
        quickfix.field.LoanLtc value = new quickfix.field.LoanLtc();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.LoanLtc field) {
        return isSetField(field);
    }

    public boolean isSetLoanLtc() {
        return isSetField(1628);
    }
    
    public void set(quickfix.field.NetAsset value) {
        setField(value);
    }

    public quickfix.field.NetAsset get(quickfix.field.NetAsset value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.NetAsset getNetAsset() throws FieldNotFound {
        quickfix.field.NetAsset value = new quickfix.field.NetAsset();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.NetAsset field) {
        return isSetField(field);
    }

    public boolean isSetNetAsset() {
        return isSetField(1628);
    }
    
    public void set(quickfix.field.Total value) {
        setField(value);
    }

    public quickfix.field.Total get(quickfix.field.Total value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.Total getTotal() throws FieldNotFound {
        quickfix.field.Total value = new quickfix.field.Total();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.Total field) {
        return isSetField(field);
    }

    public boolean isSetTotal() {
        return isSetField(1628);
    }
}
