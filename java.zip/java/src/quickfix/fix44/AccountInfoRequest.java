package quickfix.fix44;

import quickfix.FieldNotFound;

public class AccountInfoRequest extends Message {

	private static final long serialVersionUID = -3886270686642883471L;
	public static final String MSGTYPE = "Z1000";

	public AccountInfoRequest() {
		super();
		getHeader().setField(new quickfix.field.MsgType(MSGTYPE));
	}

	public void set(quickfix.field.Account value) {
		setField(value);
	}
	public void set(quickfix.field.Created value) {
		setField(value);
	}

	public void set(quickfix.field.AccessKey value) {
		setField(value);
	}
	public void set(quickfix.field.Sign value) {
        setField(value);
	}

	public quickfix.field.Account get(quickfix.field.Account value)
			throws FieldNotFound {
		getField(value);
		return value;
	}
	public quickfix.field.Created get(quickfix.field.Created value)
			throws FieldNotFound {
		getField(value);
		return value;
	}
	public quickfix.field.AccessKey get(quickfix.field.AccessKey value)
			throws FieldNotFound {
		getField(value);
		return value;
	}
	public quickfix.field.Sign get(quickfix.field.Sign value)
			throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.Account getAccount() throws FieldNotFound {
		quickfix.field.Account value = new quickfix.field.Account();
		getField(value);
		return value;
	}
	public quickfix.field.Created getCreated() throws FieldNotFound {
		quickfix.field.Created value = new quickfix.field.Created();
		getField(value);
		return value;
	}
	public quickfix.field.AccessKey getAccessKey() throws FieldNotFound {
		quickfix.field.AccessKey value = new quickfix.field.AccessKey();
		getField(value);
		return value;
	}
	public quickfix.field.Account getSign() throws FieldNotFound {
		quickfix.field.Account value = new quickfix.field.Account();
		getField(value);
		return value;
	}
	
	public boolean isSet(quickfix.field.Created field) {
		return isSetField(field);
	}
	public boolean isSet(quickfix.field.AccessKey field) {
		return isSetField(field);
	}
	public boolean isSet(quickfix.field.Sign field) {
		return isSetField(field);
	}
	public boolean isSet(quickfix.field.Account field) {
		return isSetField(field);
	}

	public boolean isSetAccount() {
		return isSetField(1);
	}
	public boolean isSetCreated() {
		return isSetField(957);
	}
	public boolean isSetAccessKey() {
		return isSetField(958);
	}
	public boolean isSetSign() {
		return isSetField(959);
	}

	public void set(quickfix.field.AccReqID value) {
		setField(value);
	}

	public quickfix.field.AccReqID get(quickfix.field.AccReqID value)
			throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.AccReqID getAccReqID() throws FieldNotFound {
		quickfix.field.AccReqID value = new quickfix.field.AccReqID();
		getField(value);
		return value;
	}

	public boolean isSet(quickfix.field.AccReqID field) {
		return isSetField(field);
	}

	public boolean isSetAccReqID() {
		return isSetField(1622);
	}
}
