package quickfix.fix44;

import quickfix.FieldNotFound;

public class HuobiOrderInfoResponse extends Message {

	private static final long serialVersionUID = -52644482800373553L;
	public static final String MSGTYPE = "Z1003";

	public HuobiOrderInfoResponse() {
		super();
		getHeader().setField(new quickfix.field.MsgType(MSGTYPE));
	}

	public void set(quickfix.field.OrderID value) {
		setField(value);
	}

	public quickfix.field.OrderID get(quickfix.field.OrderID value)
			throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.OrderID getOrderID() throws FieldNotFound {
		quickfix.field.OrderID value = new quickfix.field.OrderID();
		getField(value);
		return value;
	}

	public boolean isSet(quickfix.field.OrderID field) {
		return isSetField(field);
	}

	public boolean isSetOrderID() {
		return isSetField(37);
	}

	public void set(quickfix.field.Side value) {
		setField(value);
	}

	public quickfix.field.Side get(quickfix.field.Side value)
			throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.Side getSide() throws FieldNotFound {
		quickfix.field.Side value = new quickfix.field.Side();
		getField(value);
		return value;
	}

	public boolean isSet(quickfix.field.Side field) {
		return isSetField(field);
	}

	public boolean isSetSide() {
		return isSetField(54);
	}

	public void set(quickfix.field.Price value) {
		setField(value);
	}

	public quickfix.field.Price get(quickfix.field.Price value)
			throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.Price getPrice() throws FieldNotFound {
		quickfix.field.Price value = new quickfix.field.Price();
		getField(value);
		return value;
	}

	public boolean isSet(quickfix.field.Price field) {
		return isSetField(field);
	}

	public boolean isSetPrice() {
		return isSetField(6);
	}

	public void set(quickfix.field.OrdStatus value) {
		setField(value);
	}

	public quickfix.field.OrdStatus get(quickfix.field.OrdStatus value)
			throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.OrdStatus getOrdStatus() throws FieldNotFound {
		quickfix.field.OrdStatus value = new quickfix.field.OrdStatus();
		getField(value);
		return value;
	}

	public boolean isSet(quickfix.field.OrdStatus field) {
		return isSetField(field);
	}

	public boolean isSetOrdStatus() {
		return isSetField(39);
	}

	public void set(quickfix.field.Quantity value) {
		setField(value);
	}

	public quickfix.field.Quantity get(quickfix.field.Quantity value)
			throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.Quantity getQuantity() throws FieldNotFound {
		quickfix.field.Quantity value = new quickfix.field.Quantity();
		getField(value);
		return value;
	}

	public boolean isSet(quickfix.field.Quantity field) {
		return isSetField(field);
	}

	public boolean isSetQuantity() {
		return isSetField(53);
	}

	public void set(quickfix.field.ProcessedPrice value) {
		setField(value);
	}

	public quickfix.field.ProcessedPrice get(quickfix.field.ProcessedPrice value)
			throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.ProcessedPrice getProcessedPrice()
			throws FieldNotFound {
		quickfix.field.ProcessedPrice value = new quickfix.field.ProcessedPrice();
		getField(value);
		return value;
	}

	public boolean isSet(quickfix.field.ProcessedPrice field) {
		return isSetField(field);
	}

	public boolean isSetProcessedPrice() {
		return isSetField(1630);
	}

	public void set(quickfix.field.ProcessedAmount value) {
		setField(value);
	}

	public quickfix.field.ProcessedAmount get(
			quickfix.field.ProcessedAmount value) throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.ProcessedAmount getProcessedAmount()
			throws FieldNotFound {
		quickfix.field.ProcessedAmount value = new quickfix.field.ProcessedAmount();
		getField(value);
		return value;
	}

	public boolean isSet(quickfix.field.ProcessedAmount field) {
		return isSetField(field);
	}

	public boolean isSetProcessedAmount() {
		return isSetField(1631);
	}

	public void set(quickfix.field.Vot value) {
		setField(value);
	}

	public quickfix.field.Vot get(quickfix.field.Vot value)
			throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.Vot getVot() throws FieldNotFound {
		quickfix.field.Vot value = new quickfix.field.Vot();
		getField(value);
		return value;
	}

	public boolean isSet(quickfix.field.Vot field) {
		return isSetField(field);
	}

	public boolean isSetVot() {
		return isSetField(1632);
	}

	public void set(quickfix.field.Fee value) {
		setField(value);
	}

	public quickfix.field.Fee get(quickfix.field.Fee value)
			throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.Fee getFee() throws FieldNotFound {
		quickfix.field.Fee value = new quickfix.field.Fee();
		getField(value);
		return value;
	}

	public boolean isSet(quickfix.field.Fee field) {
		return isSetField(field);
	}

	public boolean isSetFee() {
		return isSetField(1633);
	}

	public void set(quickfix.field.Total value) {
		setField(value);
	}

	public quickfix.field.Total get(quickfix.field.Total value)
			throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.Total getTotal() throws FieldNotFound {
		quickfix.field.Total value = new quickfix.field.Total();
		getField(value);
		return value;
	}

	public boolean isSet(quickfix.field.Total field) {
		return isSetField(field);
	}

	public boolean isSetTotal() {
		return isSetField(1634);
	}

	// Symbol

	public void set(quickfix.field.Symbol value) {
		setField(value);
	}

	public quickfix.field.Symbol get(quickfix.field.Symbol value)
			throws FieldNotFound {
		getField(value);
		return value;
	}

	public quickfix.field.Symbol getSymbol() throws FieldNotFound {
		quickfix.field.Symbol value = new quickfix.field.Symbol();
		getField(value);
		return value;
	}

	public boolean isSet(quickfix.field.Symbol field) {
		return isSetField(field);
	}

	public boolean isSetSymbol() {
		return isSetField(55);
	}
}
