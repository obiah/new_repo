package quickfix.fix50;

import quickfix.FieldNotFound;
import quickfix.Group;


public class SettlementInstructionRequest extends Message {
    static final long serialVersionUID = 20050617;
    public static final String MSGTYPE = "AV";

    public SettlementInstructionRequest() {
        super();
        getHeader().setField(new quickfix.field.MsgType(MSGTYPE));
    }

    public SettlementInstructionRequest(
        quickfix.field.SettlInstReqID settlInstReqID,
        quickfix.field.TransactTime transactTime) {
        this();
        setField(settlInstReqID);
        setField(transactTime);
    }

    public void set(quickfix.field.SettlInstReqID value) {
        setField(value);
    }

    public quickfix.field.SettlInstReqID get(
        quickfix.field.SettlInstReqID value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.SettlInstReqID getSettlInstReqID()
        throws FieldNotFound {
        quickfix.field.SettlInstReqID value = new quickfix.field.SettlInstReqID();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.SettlInstReqID field) {
        return isSetField(field);
    }

    public boolean isSetSettlInstReqID() {
        return isSetField(791);
    }

    public void set(quickfix.field.TransactTime value) {
        setField(value);
    }

    public quickfix.field.TransactTime get(quickfix.field.TransactTime value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.TransactTime getTransactTime()
        throws FieldNotFound {
        quickfix.field.TransactTime value = new quickfix.field.TransactTime();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.TransactTime field) {
        return isSetField(field);
    }

    public boolean isSetTransactTime() {
        return isSetField(60);
    }

    public void set(quickfix.fix50.component.Parties component) {
        setComponent(component);
    }

    public quickfix.fix50.component.Parties get(
        quickfix.fix50.component.Parties component) throws FieldNotFound {
        getComponent(component);

        return component;
    }

    public quickfix.fix50.component.Parties getParties()
        throws FieldNotFound {
        quickfix.fix50.component.Parties component = new quickfix.fix50.component.Parties();
        getComponent(component);

        return component;
    }

    public void set(quickfix.field.NoPartyIDs value) {
        setField(value);
    }

    public quickfix.field.NoPartyIDs get(quickfix.field.NoPartyIDs value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.NoPartyIDs getNoPartyIDs() throws FieldNotFound {
        quickfix.field.NoPartyIDs value = new quickfix.field.NoPartyIDs();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.NoPartyIDs field) {
        return isSetField(field);
    }

    public boolean isSetNoPartyIDs() {
        return isSetField(453);
    }

    public void set(quickfix.field.AllocAccount value) {
        setField(value);
    }

    public quickfix.field.AllocAccount get(quickfix.field.AllocAccount value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.AllocAccount getAllocAccount()
        throws FieldNotFound {
        quickfix.field.AllocAccount value = new quickfix.field.AllocAccount();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.AllocAccount field) {
        return isSetField(field);
    }

    public boolean isSetAllocAccount() {
        return isSetField(79);
    }

    public void set(quickfix.field.AllocAcctIDSource value) {
        setField(value);
    }

    public quickfix.field.AllocAcctIDSource get(
        quickfix.field.AllocAcctIDSource value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.AllocAcctIDSource getAllocAcctIDSource()
        throws FieldNotFound {
        quickfix.field.AllocAcctIDSource value = new quickfix.field.AllocAcctIDSource();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.AllocAcctIDSource field) {
        return isSetField(field);
    }

    public boolean isSetAllocAcctIDSource() {
        return isSetField(661);
    }

    public void set(quickfix.field.Side value) {
        setField(value);
    }

    public quickfix.field.Side get(quickfix.field.Side value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.Side getSide() throws FieldNotFound {
        quickfix.field.Side value = new quickfix.field.Side();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.Side field) {
        return isSetField(field);
    }

    public boolean isSetSide() {
        return isSetField(54);
    }

    public void set(quickfix.field.Product value) {
        setField(value);
    }

    public quickfix.field.Product get(quickfix.field.Product value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.Product getProduct() throws FieldNotFound {
        quickfix.field.Product value = new quickfix.field.Product();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.Product field) {
        return isSetField(field);
    }

    public boolean isSetProduct() {
        return isSetField(460);
    }

    public void set(quickfix.field.SecurityType value) {
        setField(value);
    }

    public quickfix.field.SecurityType get(quickfix.field.SecurityType value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.SecurityType getSecurityType()
        throws FieldNotFound {
        quickfix.field.SecurityType value = new quickfix.field.SecurityType();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.SecurityType field) {
        return isSetField(field);
    }

    public boolean isSetSecurityType() {
        return isSetField(167);
    }

    public void set(quickfix.field.CFICode value) {
        setField(value);
    }

    public quickfix.field.CFICode get(quickfix.field.CFICode value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.CFICode getCFICode() throws FieldNotFound {
        quickfix.field.CFICode value = new quickfix.field.CFICode();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.CFICode field) {
        return isSetField(field);
    }

    public boolean isSetCFICode() {
        return isSetField(461);
    }

    public void set(quickfix.field.EffectiveTime value) {
        setField(value);
    }

    public quickfix.field.EffectiveTime get(quickfix.field.EffectiveTime value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.EffectiveTime getEffectiveTime()
        throws FieldNotFound {
        quickfix.field.EffectiveTime value = new quickfix.field.EffectiveTime();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.EffectiveTime field) {
        return isSetField(field);
    }

    public boolean isSetEffectiveTime() {
        return isSetField(168);
    }

    public void set(quickfix.field.ExpireTime value) {
        setField(value);
    }

    public quickfix.field.ExpireTime get(quickfix.field.ExpireTime value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.ExpireTime getExpireTime() throws FieldNotFound {
        quickfix.field.ExpireTime value = new quickfix.field.ExpireTime();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.ExpireTime field) {
        return isSetField(field);
    }

    public boolean isSetExpireTime() {
        return isSetField(126);
    }

    public void set(quickfix.field.LastUpdateTime value) {
        setField(value);
    }

    public quickfix.field.LastUpdateTime get(
        quickfix.field.LastUpdateTime value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.LastUpdateTime getLastUpdateTime()
        throws FieldNotFound {
        quickfix.field.LastUpdateTime value = new quickfix.field.LastUpdateTime();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.LastUpdateTime field) {
        return isSetField(field);
    }

    public boolean isSetLastUpdateTime() {
        return isSetField(779);
    }

    public void set(quickfix.field.StandInstDbType value) {
        setField(value);
    }

    public quickfix.field.StandInstDbType get(
        quickfix.field.StandInstDbType value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.StandInstDbType getStandInstDbType()
        throws FieldNotFound {
        quickfix.field.StandInstDbType value = new quickfix.field.StandInstDbType();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.StandInstDbType field) {
        return isSetField(field);
    }

    public boolean isSetStandInstDbType() {
        return isSetField(169);
    }

    public void set(quickfix.field.StandInstDbName value) {
        setField(value);
    }

    public quickfix.field.StandInstDbName get(
        quickfix.field.StandInstDbName value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.StandInstDbName getStandInstDbName()
        throws FieldNotFound {
        quickfix.field.StandInstDbName value = new quickfix.field.StandInstDbName();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.StandInstDbName field) {
        return isSetField(field);
    }

    public boolean isSetStandInstDbName() {
        return isSetField(170);
    }

    public void set(quickfix.field.StandInstDbID value) {
        setField(value);
    }

    public quickfix.field.StandInstDbID get(quickfix.field.StandInstDbID value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.StandInstDbID getStandInstDbID()
        throws FieldNotFound {
        quickfix.field.StandInstDbID value = new quickfix.field.StandInstDbID();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.StandInstDbID field) {
        return isSetField(field);
    }

    public boolean isSetStandInstDbID() {
        return isSetField(171);
    }

    public void set(quickfix.field.SettlCurrency value) {
        setField(value);
    }

    public quickfix.field.SettlCurrency get(quickfix.field.SettlCurrency value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.SettlCurrency getSettlCurrency()
        throws FieldNotFound {
        quickfix.field.SettlCurrency value = new quickfix.field.SettlCurrency();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.SettlCurrency field) {
        return isSetField(field);
    }

    public boolean isSetSettlCurrency() {
        return isSetField(120);
    }

    public static class NoPartyIDs extends Group {
        static final long serialVersionUID = 20050617;

        public NoPartyIDs() {
            super(453, 448, new int[] { 448, 447, 452, 802, 0 });
        }

        public void set(quickfix.field.PartyID value) {
            setField(value);
        }

        public quickfix.field.PartyID get(quickfix.field.PartyID value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.PartyID getPartyID() throws FieldNotFound {
            quickfix.field.PartyID value = new quickfix.field.PartyID();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.PartyID field) {
            return isSetField(field);
        }

        public boolean isSetPartyID() {
            return isSetField(448);
        }

        public void set(quickfix.field.PartyIDSource value) {
            setField(value);
        }

        public quickfix.field.PartyIDSource get(
            quickfix.field.PartyIDSource value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.PartyIDSource getPartyIDSource()
            throws FieldNotFound {
            quickfix.field.PartyIDSource value = new quickfix.field.PartyIDSource();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.PartyIDSource field) {
            return isSetField(field);
        }

        public boolean isSetPartyIDSource() {
            return isSetField(447);
        }

        public void set(quickfix.field.PartyRole value) {
            setField(value);
        }

        public quickfix.field.PartyRole get(quickfix.field.PartyRole value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.PartyRole getPartyRole()
            throws FieldNotFound {
            quickfix.field.PartyRole value = new quickfix.field.PartyRole();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.PartyRole field) {
            return isSetField(field);
        }

        public boolean isSetPartyRole() {
            return isSetField(452);
        }

        public void set(quickfix.fix50.component.PtysSubGrp component) {
            setComponent(component);
        }

        public quickfix.fix50.component.PtysSubGrp get(
            quickfix.fix50.component.PtysSubGrp component)
            throws FieldNotFound {
            getComponent(component);

            return component;
        }

        public quickfix.fix50.component.PtysSubGrp getPtysSubGrp()
            throws FieldNotFound {
            quickfix.fix50.component.PtysSubGrp component = new quickfix.fix50.component.PtysSubGrp();
            getComponent(component);

            return component;
        }

        public void set(quickfix.field.NoPartySubIDs value) {
            setField(value);
        }

        public quickfix.field.NoPartySubIDs get(
            quickfix.field.NoPartySubIDs value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.NoPartySubIDs getNoPartySubIDs()
            throws FieldNotFound {
            quickfix.field.NoPartySubIDs value = new quickfix.field.NoPartySubIDs();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.NoPartySubIDs field) {
            return isSetField(field);
        }

        public boolean isSetNoPartySubIDs() {
            return isSetField(802);
        }

        public static class NoPartySubIDs extends Group {
            static final long serialVersionUID = 20050617;

            public NoPartySubIDs() {
                super(802, 523, new int[] { 523, 803, 0 });
            }

            public void set(quickfix.field.PartySubID value) {
                setField(value);
            }

            public quickfix.field.PartySubID get(
                quickfix.field.PartySubID value) throws FieldNotFound {
                getField(value);

                return value;
            }

            public quickfix.field.PartySubID getPartySubID()
                throws FieldNotFound {
                quickfix.field.PartySubID value = new quickfix.field.PartySubID();
                getField(value);

                return value;
            }

            public boolean isSet(quickfix.field.PartySubID field) {
                return isSetField(field);
            }

            public boolean isSetPartySubID() {
                return isSetField(523);
            }

            public void set(quickfix.field.PartySubIDType value) {
                setField(value);
            }

            public quickfix.field.PartySubIDType get(
                quickfix.field.PartySubIDType value) throws FieldNotFound {
                getField(value);

                return value;
            }

            public quickfix.field.PartySubIDType getPartySubIDType()
                throws FieldNotFound {
                quickfix.field.PartySubIDType value = new quickfix.field.PartySubIDType();
                getField(value);

                return value;
            }

            public boolean isSet(quickfix.field.PartySubIDType field) {
                return isSetField(field);
            }

            public boolean isSetPartySubIDType() {
                return isSetField(803);
            }
        }
    }
}
