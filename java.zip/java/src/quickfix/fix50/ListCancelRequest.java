package quickfix.fix50;

import quickfix.FieldNotFound;
import quickfix.Group;


public class ListCancelRequest extends Message {
    static final long serialVersionUID = 20050617;
    public static final String MSGTYPE = "K";

    public ListCancelRequest() {
        super();
        getHeader().setField(new quickfix.field.MsgType(MSGTYPE));
    }

    public ListCancelRequest(quickfix.field.ListID listID,
        quickfix.field.TransactTime transactTime) {
        this();
        setField(listID);
        setField(transactTime);
    }

    public void set(quickfix.field.ListID value) {
        setField(value);
    }

    public quickfix.field.ListID get(quickfix.field.ListID value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.ListID getListID() throws FieldNotFound {
        quickfix.field.ListID value = new quickfix.field.ListID();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.ListID field) {
        return isSetField(field);
    }

    public boolean isSetListID() {
        return isSetField(66);
    }

    public void set(quickfix.field.TransactTime value) {
        setField(value);
    }

    public quickfix.field.TransactTime get(quickfix.field.TransactTime value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.TransactTime getTransactTime()
        throws FieldNotFound {
        quickfix.field.TransactTime value = new quickfix.field.TransactTime();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.TransactTime field) {
        return isSetField(field);
    }

    public boolean isSetTransactTime() {
        return isSetField(60);
    }

    public void set(quickfix.field.TradeOriginationDate value) {
        setField(value);
    }

    public quickfix.field.TradeOriginationDate get(
        quickfix.field.TradeOriginationDate value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.TradeOriginationDate getTradeOriginationDate()
        throws FieldNotFound {
        quickfix.field.TradeOriginationDate value = new quickfix.field.TradeOriginationDate();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.TradeOriginationDate field) {
        return isSetField(field);
    }

    public boolean isSetTradeOriginationDate() {
        return isSetField(229);
    }

    public void set(quickfix.field.TradeDate value) {
        setField(value);
    }

    public quickfix.field.TradeDate get(quickfix.field.TradeDate value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.TradeDate getTradeDate() throws FieldNotFound {
        quickfix.field.TradeDate value = new quickfix.field.TradeDate();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.TradeDate field) {
        return isSetField(field);
    }

    public boolean isSetTradeDate() {
        return isSetField(75);
    }

    public void set(quickfix.field.Text value) {
        setField(value);
    }

    public quickfix.field.Text get(quickfix.field.Text value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.Text getText() throws FieldNotFound {
        quickfix.field.Text value = new quickfix.field.Text();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.Text field) {
        return isSetField(field);
    }

    public boolean isSetText() {
        return isSetField(58);
    }

    public void set(quickfix.field.EncodedTextLen value) {
        setField(value);
    }

    public quickfix.field.EncodedTextLen get(
        quickfix.field.EncodedTextLen value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.EncodedTextLen getEncodedTextLen()
        throws FieldNotFound {
        quickfix.field.EncodedTextLen value = new quickfix.field.EncodedTextLen();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.EncodedTextLen field) {
        return isSetField(field);
    }

    public boolean isSetEncodedTextLen() {
        return isSetField(354);
    }

    public void set(quickfix.field.EncodedText value) {
        setField(value);
    }

    public quickfix.field.EncodedText get(quickfix.field.EncodedText value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.EncodedText getEncodedText()
        throws FieldNotFound {
        quickfix.field.EncodedText value = new quickfix.field.EncodedText();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.EncodedText field) {
        return isSetField(field);
    }

    public boolean isSetEncodedText() {
        return isSetField(355);
    }

    public void set(quickfix.fix50.component.Parties component) {
        setComponent(component);
    }

    public quickfix.fix50.component.Parties get(
        quickfix.fix50.component.Parties component) throws FieldNotFound {
        getComponent(component);

        return component;
    }

    public quickfix.fix50.component.Parties getParties()
        throws FieldNotFound {
        quickfix.fix50.component.Parties component = new quickfix.fix50.component.Parties();
        getComponent(component);

        return component;
    }

    public void set(quickfix.field.NoPartyIDs value) {
        setField(value);
    }

    public quickfix.field.NoPartyIDs get(quickfix.field.NoPartyIDs value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.NoPartyIDs getNoPartyIDs() throws FieldNotFound {
        quickfix.field.NoPartyIDs value = new quickfix.field.NoPartyIDs();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.NoPartyIDs field) {
        return isSetField(field);
    }

    public boolean isSetNoPartyIDs() {
        return isSetField(453);
    }

    public static class NoPartyIDs extends Group {
        static final long serialVersionUID = 20050617;

        public NoPartyIDs() {
            super(453, 448, new int[] { 448, 447, 452, 802, 0 });
        }

        public void set(quickfix.field.PartyID value) {
            setField(value);
        }

        public quickfix.field.PartyID get(quickfix.field.PartyID value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.PartyID getPartyID() throws FieldNotFound {
            quickfix.field.PartyID value = new quickfix.field.PartyID();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.PartyID field) {
            return isSetField(field);
        }

        public boolean isSetPartyID() {
            return isSetField(448);
        }

        public void set(quickfix.field.PartyIDSource value) {
            setField(value);
        }

        public quickfix.field.PartyIDSource get(
            quickfix.field.PartyIDSource value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.PartyIDSource getPartyIDSource()
            throws FieldNotFound {
            quickfix.field.PartyIDSource value = new quickfix.field.PartyIDSource();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.PartyIDSource field) {
            return isSetField(field);
        }

        public boolean isSetPartyIDSource() {
            return isSetField(447);
        }

        public void set(quickfix.field.PartyRole value) {
            setField(value);
        }

        public quickfix.field.PartyRole get(quickfix.field.PartyRole value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.PartyRole getPartyRole()
            throws FieldNotFound {
            quickfix.field.PartyRole value = new quickfix.field.PartyRole();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.PartyRole field) {
            return isSetField(field);
        }

        public boolean isSetPartyRole() {
            return isSetField(452);
        }

        public void set(quickfix.fix50.component.PtysSubGrp component) {
            setComponent(component);
        }

        public quickfix.fix50.component.PtysSubGrp get(
            quickfix.fix50.component.PtysSubGrp component)
            throws FieldNotFound {
            getComponent(component);

            return component;
        }

        public quickfix.fix50.component.PtysSubGrp getPtysSubGrp()
            throws FieldNotFound {
            quickfix.fix50.component.PtysSubGrp component = new quickfix.fix50.component.PtysSubGrp();
            getComponent(component);

            return component;
        }

        public void set(quickfix.field.NoPartySubIDs value) {
            setField(value);
        }

        public quickfix.field.NoPartySubIDs get(
            quickfix.field.NoPartySubIDs value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.NoPartySubIDs getNoPartySubIDs()
            throws FieldNotFound {
            quickfix.field.NoPartySubIDs value = new quickfix.field.NoPartySubIDs();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.NoPartySubIDs field) {
            return isSetField(field);
        }

        public boolean isSetNoPartySubIDs() {
            return isSetField(802);
        }

        public static class NoPartySubIDs extends Group {
            static final long serialVersionUID = 20050617;

            public NoPartySubIDs() {
                super(802, 523, new int[] { 523, 803, 0 });
            }

            public void set(quickfix.field.PartySubID value) {
                setField(value);
            }

            public quickfix.field.PartySubID get(
                quickfix.field.PartySubID value) throws FieldNotFound {
                getField(value);

                return value;
            }

            public quickfix.field.PartySubID getPartySubID()
                throws FieldNotFound {
                quickfix.field.PartySubID value = new quickfix.field.PartySubID();
                getField(value);

                return value;
            }

            public boolean isSet(quickfix.field.PartySubID field) {
                return isSetField(field);
            }

            public boolean isSetPartySubID() {
                return isSetField(523);
            }

            public void set(quickfix.field.PartySubIDType value) {
                setField(value);
            }

            public quickfix.field.PartySubIDType get(
                quickfix.field.PartySubIDType value) throws FieldNotFound {
                getField(value);

                return value;
            }

            public quickfix.field.PartySubIDType getPartySubIDType()
                throws FieldNotFound {
                quickfix.field.PartySubIDType value = new quickfix.field.PartySubIDType();
                getField(value);

                return value;
            }

            public boolean isSet(quickfix.field.PartySubIDType field) {
                return isSetField(field);
            }

            public boolean isSetPartySubIDType() {
                return isSetField(803);
            }
        }
    }
}
