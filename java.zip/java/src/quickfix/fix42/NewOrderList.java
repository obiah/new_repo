package quickfix.fix42;

import quickfix.FieldNotFound;
import quickfix.Group;


public class NewOrderList extends Message {
    static final long serialVersionUID = 20050617;
    public static final String MSGTYPE = "E";

    public NewOrderList() {
        super();
        getHeader().setField(new quickfix.field.MsgType(MSGTYPE));
    }

    public NewOrderList(quickfix.field.ListID listID,
        quickfix.field.BidType bidType, quickfix.field.TotNoOrders totNoOrders) {
        this();
        setField(listID);
        setField(bidType);
        setField(totNoOrders);
    }

    public void set(quickfix.field.ListID value) {
        setField(value);
    }

    public quickfix.field.ListID get(quickfix.field.ListID value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.ListID getListID() throws FieldNotFound {
        quickfix.field.ListID value = new quickfix.field.ListID();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.ListID field) {
        return isSetField(field);
    }

    public boolean isSetListID() {
        return isSetField(66);
    }

    public void set(quickfix.field.BidID value) {
        setField(value);
    }

    public quickfix.field.BidID get(quickfix.field.BidID value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.BidID getBidID() throws FieldNotFound {
        quickfix.field.BidID value = new quickfix.field.BidID();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.BidID field) {
        return isSetField(field);
    }

    public boolean isSetBidID() {
        return isSetField(390);
    }

    public void set(quickfix.field.ClientBidID value) {
        setField(value);
    }

    public quickfix.field.ClientBidID get(quickfix.field.ClientBidID value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.ClientBidID getClientBidID()
        throws FieldNotFound {
        quickfix.field.ClientBidID value = new quickfix.field.ClientBidID();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.ClientBidID field) {
        return isSetField(field);
    }

    public boolean isSetClientBidID() {
        return isSetField(391);
    }

    public void set(quickfix.field.ProgRptReqs value) {
        setField(value);
    }

    public quickfix.field.ProgRptReqs get(quickfix.field.ProgRptReqs value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.ProgRptReqs getProgRptReqs()
        throws FieldNotFound {
        quickfix.field.ProgRptReqs value = new quickfix.field.ProgRptReqs();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.ProgRptReqs field) {
        return isSetField(field);
    }

    public boolean isSetProgRptReqs() {
        return isSetField(414);
    }

    public void set(quickfix.field.BidType value) {
        setField(value);
    }

    public quickfix.field.BidType get(quickfix.field.BidType value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.BidType getBidType() throws FieldNotFound {
        quickfix.field.BidType value = new quickfix.field.BidType();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.BidType field) {
        return isSetField(field);
    }

    public boolean isSetBidType() {
        return isSetField(394);
    }

    public void set(quickfix.field.ProgPeriodInterval value) {
        setField(value);
    }

    public quickfix.field.ProgPeriodInterval get(
        quickfix.field.ProgPeriodInterval value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.ProgPeriodInterval getProgPeriodInterval()
        throws FieldNotFound {
        quickfix.field.ProgPeriodInterval value = new quickfix.field.ProgPeriodInterval();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.ProgPeriodInterval field) {
        return isSetField(field);
    }

    public boolean isSetProgPeriodInterval() {
        return isSetField(415);
    }

    public void set(quickfix.field.ListExecInstType value) {
        setField(value);
    }

    public quickfix.field.ListExecInstType get(
        quickfix.field.ListExecInstType value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.ListExecInstType getListExecInstType()
        throws FieldNotFound {
        quickfix.field.ListExecInstType value = new quickfix.field.ListExecInstType();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.ListExecInstType field) {
        return isSetField(field);
    }

    public boolean isSetListExecInstType() {
        return isSetField(433);
    }

    public void set(quickfix.field.ListExecInst value) {
        setField(value);
    }

    public quickfix.field.ListExecInst get(quickfix.field.ListExecInst value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.ListExecInst getListExecInst()
        throws FieldNotFound {
        quickfix.field.ListExecInst value = new quickfix.field.ListExecInst();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.ListExecInst field) {
        return isSetField(field);
    }

    public boolean isSetListExecInst() {
        return isSetField(69);
    }

    public void set(quickfix.field.EncodedListExecInstLen value) {
        setField(value);
    }

    public quickfix.field.EncodedListExecInstLen get(
        quickfix.field.EncodedListExecInstLen value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.EncodedListExecInstLen getEncodedListExecInstLen()
        throws FieldNotFound {
        quickfix.field.EncodedListExecInstLen value = new quickfix.field.EncodedListExecInstLen();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.EncodedListExecInstLen field) {
        return isSetField(field);
    }

    public boolean isSetEncodedListExecInstLen() {
        return isSetField(352);
    }

    public void set(quickfix.field.EncodedListExecInst value) {
        setField(value);
    }

    public quickfix.field.EncodedListExecInst get(
        quickfix.field.EncodedListExecInst value) throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.EncodedListExecInst getEncodedListExecInst()
        throws FieldNotFound {
        quickfix.field.EncodedListExecInst value = new quickfix.field.EncodedListExecInst();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.EncodedListExecInst field) {
        return isSetField(field);
    }

    public boolean isSetEncodedListExecInst() {
        return isSetField(353);
    }

    public void set(quickfix.field.TotNoOrders value) {
        setField(value);
    }

    public quickfix.field.TotNoOrders get(quickfix.field.TotNoOrders value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.TotNoOrders getTotNoOrders()
        throws FieldNotFound {
        quickfix.field.TotNoOrders value = new quickfix.field.TotNoOrders();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.TotNoOrders field) {
        return isSetField(field);
    }

    public boolean isSetTotNoOrders() {
        return isSetField(68);
    }

    public void set(quickfix.field.NoOrders value) {
        setField(value);
    }

    public quickfix.field.NoOrders get(quickfix.field.NoOrders value)
        throws FieldNotFound {
        getField(value);

        return value;
    }

    public quickfix.field.NoOrders getNoOrders() throws FieldNotFound {
        quickfix.field.NoOrders value = new quickfix.field.NoOrders();
        getField(value);

        return value;
    }

    public boolean isSet(quickfix.field.NoOrders field) {
        return isSetField(field);
    }

    public boolean isSetNoOrders() {
        return isSetField(73);
    }

    public static class NoOrders extends Group {
        static final long serialVersionUID = 20050617;

        public NoOrders() {
            super(73, 11,
                new int[] {
                    11, 67, 160, 109, 76, 1, 78, 63, 64, 21, 18, 110, 111, 100,
                    386, 81, 55, 65, 48, 22, 167, 200, 205, 201, 202, 206, 231,
                    223, 207, 106, 348, 349, 107, 350, 351, 140, 54, 401, 114,
                    60, 38, 152, 40, 44, 99, 15, 376, 377, 23, 117, 59, 168, 432,
                    126, 427, 12, 13, 47, 121, 120, 58, 354, 355, 193, 192, 77,
                    203, 204, 210, 211, 388, 389, 439, 440, 0
                });
        }

        public void set(quickfix.field.ClOrdID value) {
            setField(value);
        }

        public quickfix.field.ClOrdID get(quickfix.field.ClOrdID value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.ClOrdID getClOrdID() throws FieldNotFound {
            quickfix.field.ClOrdID value = new quickfix.field.ClOrdID();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.ClOrdID field) {
            return isSetField(field);
        }

        public boolean isSetClOrdID() {
            return isSetField(11);
        }

        public void set(quickfix.field.ListSeqNo value) {
            setField(value);
        }

        public quickfix.field.ListSeqNo get(quickfix.field.ListSeqNo value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.ListSeqNo getListSeqNo()
            throws FieldNotFound {
            quickfix.field.ListSeqNo value = new quickfix.field.ListSeqNo();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.ListSeqNo field) {
            return isSetField(field);
        }

        public boolean isSetListSeqNo() {
            return isSetField(67);
        }

        public void set(quickfix.field.SettlInstMode value) {
            setField(value);
        }

        public quickfix.field.SettlInstMode get(
            quickfix.field.SettlInstMode value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.SettlInstMode getSettlInstMode()
            throws FieldNotFound {
            quickfix.field.SettlInstMode value = new quickfix.field.SettlInstMode();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.SettlInstMode field) {
            return isSetField(field);
        }

        public boolean isSetSettlInstMode() {
            return isSetField(160);
        }

        public void set(quickfix.field.ClientID value) {
            setField(value);
        }

        public quickfix.field.ClientID get(quickfix.field.ClientID value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.ClientID getClientID() throws FieldNotFound {
            quickfix.field.ClientID value = new quickfix.field.ClientID();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.ClientID field) {
            return isSetField(field);
        }

        public boolean isSetClientID() {
            return isSetField(109);
        }

        public void set(quickfix.field.ExecBroker value) {
            setField(value);
        }

        public quickfix.field.ExecBroker get(quickfix.field.ExecBroker value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.ExecBroker getExecBroker()
            throws FieldNotFound {
            quickfix.field.ExecBroker value = new quickfix.field.ExecBroker();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.ExecBroker field) {
            return isSetField(field);
        }

        public boolean isSetExecBroker() {
            return isSetField(76);
        }

        public void set(quickfix.field.Account value) {
            setField(value);
        }

        public quickfix.field.Account get(quickfix.field.Account value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.Account getAccount() throws FieldNotFound {
            quickfix.field.Account value = new quickfix.field.Account();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.Account field) {
            return isSetField(field);
        }

        public boolean isSetAccount() {
            return isSetField(1);
        }

        public void set(quickfix.field.NoAllocs value) {
            setField(value);
        }

        public quickfix.field.NoAllocs get(quickfix.field.NoAllocs value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.NoAllocs getNoAllocs() throws FieldNotFound {
            quickfix.field.NoAllocs value = new quickfix.field.NoAllocs();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.NoAllocs field) {
            return isSetField(field);
        }

        public boolean isSetNoAllocs() {
            return isSetField(78);
        }

        public void set(quickfix.field.SettlmntTyp value) {
            setField(value);
        }

        public quickfix.field.SettlmntTyp get(quickfix.field.SettlmntTyp value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.SettlmntTyp getSettlmntTyp()
            throws FieldNotFound {
            quickfix.field.SettlmntTyp value = new quickfix.field.SettlmntTyp();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.SettlmntTyp field) {
            return isSetField(field);
        }

        public boolean isSetSettlmntTyp() {
            return isSetField(63);
        }

        public void set(quickfix.field.FutSettDate value) {
            setField(value);
        }

        public quickfix.field.FutSettDate get(quickfix.field.FutSettDate value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.FutSettDate getFutSettDate()
            throws FieldNotFound {
            quickfix.field.FutSettDate value = new quickfix.field.FutSettDate();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.FutSettDate field) {
            return isSetField(field);
        }

        public boolean isSetFutSettDate() {
            return isSetField(64);
        }

        public void set(quickfix.field.HandlInst value) {
            setField(value);
        }

        public quickfix.field.HandlInst get(quickfix.field.HandlInst value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.HandlInst getHandlInst()
            throws FieldNotFound {
            quickfix.field.HandlInst value = new quickfix.field.HandlInst();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.HandlInst field) {
            return isSetField(field);
        }

        public boolean isSetHandlInst() {
            return isSetField(21);
        }

        public void set(quickfix.field.ExecInst value) {
            setField(value);
        }

        public quickfix.field.ExecInst get(quickfix.field.ExecInst value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.ExecInst getExecInst() throws FieldNotFound {
            quickfix.field.ExecInst value = new quickfix.field.ExecInst();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.ExecInst field) {
            return isSetField(field);
        }

        public boolean isSetExecInst() {
            return isSetField(18);
        }

        public void set(quickfix.field.MinQty value) {
            setField(value);
        }

        public quickfix.field.MinQty get(quickfix.field.MinQty value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.MinQty getMinQty() throws FieldNotFound {
            quickfix.field.MinQty value = new quickfix.field.MinQty();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.MinQty field) {
            return isSetField(field);
        }

        public boolean isSetMinQty() {
            return isSetField(110);
        }

        public void set(quickfix.field.MaxFloor value) {
            setField(value);
        }

        public quickfix.field.MaxFloor get(quickfix.field.MaxFloor value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.MaxFloor getMaxFloor() throws FieldNotFound {
            quickfix.field.MaxFloor value = new quickfix.field.MaxFloor();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.MaxFloor field) {
            return isSetField(field);
        }

        public boolean isSetMaxFloor() {
            return isSetField(111);
        }

        public void set(quickfix.field.ExDestination value) {
            setField(value);
        }

        public quickfix.field.ExDestination get(
            quickfix.field.ExDestination value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.ExDestination getExDestination()
            throws FieldNotFound {
            quickfix.field.ExDestination value = new quickfix.field.ExDestination();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.ExDestination field) {
            return isSetField(field);
        }

        public boolean isSetExDestination() {
            return isSetField(100);
        }

        public void set(quickfix.field.NoTradingSessions value) {
            setField(value);
        }

        public quickfix.field.NoTradingSessions get(
            quickfix.field.NoTradingSessions value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.NoTradingSessions getNoTradingSessions()
            throws FieldNotFound {
            quickfix.field.NoTradingSessions value = new quickfix.field.NoTradingSessions();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.NoTradingSessions field) {
            return isSetField(field);
        }

        public boolean isSetNoTradingSessions() {
            return isSetField(386);
        }

        public void set(quickfix.field.ProcessCode value) {
            setField(value);
        }

        public quickfix.field.ProcessCode get(quickfix.field.ProcessCode value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.ProcessCode getProcessCode()
            throws FieldNotFound {
            quickfix.field.ProcessCode value = new quickfix.field.ProcessCode();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.ProcessCode field) {
            return isSetField(field);
        }

        public boolean isSetProcessCode() {
            return isSetField(81);
        }

        public void set(quickfix.field.Symbol value) {
            setField(value);
        }

        public quickfix.field.Symbol get(quickfix.field.Symbol value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.Symbol getSymbol() throws FieldNotFound {
            quickfix.field.Symbol value = new quickfix.field.Symbol();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.Symbol field) {
            return isSetField(field);
        }

        public boolean isSetSymbol() {
            return isSetField(55);
        }

        public void set(quickfix.field.SymbolSfx value) {
            setField(value);
        }

        public quickfix.field.SymbolSfx get(quickfix.field.SymbolSfx value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.SymbolSfx getSymbolSfx()
            throws FieldNotFound {
            quickfix.field.SymbolSfx value = new quickfix.field.SymbolSfx();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.SymbolSfx field) {
            return isSetField(field);
        }

        public boolean isSetSymbolSfx() {
            return isSetField(65);
        }

        public void set(quickfix.field.SecurityID value) {
            setField(value);
        }

        public quickfix.field.SecurityID get(quickfix.field.SecurityID value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.SecurityID getSecurityID()
            throws FieldNotFound {
            quickfix.field.SecurityID value = new quickfix.field.SecurityID();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.SecurityID field) {
            return isSetField(field);
        }

        public boolean isSetSecurityID() {
            return isSetField(48);
        }

        public void set(quickfix.field.IDSource value) {
            setField(value);
        }

        public quickfix.field.IDSource get(quickfix.field.IDSource value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.IDSource getIDSource() throws FieldNotFound {
            quickfix.field.IDSource value = new quickfix.field.IDSource();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.IDSource field) {
            return isSetField(field);
        }

        public boolean isSetIDSource() {
            return isSetField(22);
        }

        public void set(quickfix.field.SecurityType value) {
            setField(value);
        }

        public quickfix.field.SecurityType get(
            quickfix.field.SecurityType value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.SecurityType getSecurityType()
            throws FieldNotFound {
            quickfix.field.SecurityType value = new quickfix.field.SecurityType();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.SecurityType field) {
            return isSetField(field);
        }

        public boolean isSetSecurityType() {
            return isSetField(167);
        }

        public void set(quickfix.field.MaturityMonthYear value) {
            setField(value);
        }

        public quickfix.field.MaturityMonthYear get(
            quickfix.field.MaturityMonthYear value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.MaturityMonthYear getMaturityMonthYear()
            throws FieldNotFound {
            quickfix.field.MaturityMonthYear value = new quickfix.field.MaturityMonthYear();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.MaturityMonthYear field) {
            return isSetField(field);
        }

        public boolean isSetMaturityMonthYear() {
            return isSetField(200);
        }

        public void set(quickfix.field.MaturityDay value) {
            setField(value);
        }

        public quickfix.field.MaturityDay get(quickfix.field.MaturityDay value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.MaturityDay getMaturityDay()
            throws FieldNotFound {
            quickfix.field.MaturityDay value = new quickfix.field.MaturityDay();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.MaturityDay field) {
            return isSetField(field);
        }

        public boolean isSetMaturityDay() {
            return isSetField(205);
        }

        public void set(quickfix.field.PutOrCall value) {
            setField(value);
        }

        public quickfix.field.PutOrCall get(quickfix.field.PutOrCall value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.PutOrCall getPutOrCall()
            throws FieldNotFound {
            quickfix.field.PutOrCall value = new quickfix.field.PutOrCall();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.PutOrCall field) {
            return isSetField(field);
        }

        public boolean isSetPutOrCall() {
            return isSetField(201);
        }

        public void set(quickfix.field.StrikePrice value) {
            setField(value);
        }

        public quickfix.field.StrikePrice get(quickfix.field.StrikePrice value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.StrikePrice getStrikePrice()
            throws FieldNotFound {
            quickfix.field.StrikePrice value = new quickfix.field.StrikePrice();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.StrikePrice field) {
            return isSetField(field);
        }

        public boolean isSetStrikePrice() {
            return isSetField(202);
        }

        public void set(quickfix.field.OptAttribute value) {
            setField(value);
        }

        public quickfix.field.OptAttribute get(
            quickfix.field.OptAttribute value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.OptAttribute getOptAttribute()
            throws FieldNotFound {
            quickfix.field.OptAttribute value = new quickfix.field.OptAttribute();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.OptAttribute field) {
            return isSetField(field);
        }

        public boolean isSetOptAttribute() {
            return isSetField(206);
        }

        public void set(quickfix.field.ContractMultiplier value) {
            setField(value);
        }

        public quickfix.field.ContractMultiplier get(
            quickfix.field.ContractMultiplier value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.ContractMultiplier getContractMultiplier()
            throws FieldNotFound {
            quickfix.field.ContractMultiplier value = new quickfix.field.ContractMultiplier();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.ContractMultiplier field) {
            return isSetField(field);
        }

        public boolean isSetContractMultiplier() {
            return isSetField(231);
        }

        public void set(quickfix.field.CouponRate value) {
            setField(value);
        }

        public quickfix.field.CouponRate get(quickfix.field.CouponRate value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.CouponRate getCouponRate()
            throws FieldNotFound {
            quickfix.field.CouponRate value = new quickfix.field.CouponRate();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.CouponRate field) {
            return isSetField(field);
        }

        public boolean isSetCouponRate() {
            return isSetField(223);
        }

        public void set(quickfix.field.SecurityExchange value) {
            setField(value);
        }

        public quickfix.field.SecurityExchange get(
            quickfix.field.SecurityExchange value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.SecurityExchange getSecurityExchange()
            throws FieldNotFound {
            quickfix.field.SecurityExchange value = new quickfix.field.SecurityExchange();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.SecurityExchange field) {
            return isSetField(field);
        }

        public boolean isSetSecurityExchange() {
            return isSetField(207);
        }

        public void set(quickfix.field.Issuer value) {
            setField(value);
        }

        public quickfix.field.Issuer get(quickfix.field.Issuer value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.Issuer getIssuer() throws FieldNotFound {
            quickfix.field.Issuer value = new quickfix.field.Issuer();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.Issuer field) {
            return isSetField(field);
        }

        public boolean isSetIssuer() {
            return isSetField(106);
        }

        public void set(quickfix.field.EncodedIssuerLen value) {
            setField(value);
        }

        public quickfix.field.EncodedIssuerLen get(
            quickfix.field.EncodedIssuerLen value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.EncodedIssuerLen getEncodedIssuerLen()
            throws FieldNotFound {
            quickfix.field.EncodedIssuerLen value = new quickfix.field.EncodedIssuerLen();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.EncodedIssuerLen field) {
            return isSetField(field);
        }

        public boolean isSetEncodedIssuerLen() {
            return isSetField(348);
        }

        public void set(quickfix.field.EncodedIssuer value) {
            setField(value);
        }

        public quickfix.field.EncodedIssuer get(
            quickfix.field.EncodedIssuer value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.EncodedIssuer getEncodedIssuer()
            throws FieldNotFound {
            quickfix.field.EncodedIssuer value = new quickfix.field.EncodedIssuer();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.EncodedIssuer field) {
            return isSetField(field);
        }

        public boolean isSetEncodedIssuer() {
            return isSetField(349);
        }

        public void set(quickfix.field.SecurityDesc value) {
            setField(value);
        }

        public quickfix.field.SecurityDesc get(
            quickfix.field.SecurityDesc value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.SecurityDesc getSecurityDesc()
            throws FieldNotFound {
            quickfix.field.SecurityDesc value = new quickfix.field.SecurityDesc();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.SecurityDesc field) {
            return isSetField(field);
        }

        public boolean isSetSecurityDesc() {
            return isSetField(107);
        }

        public void set(quickfix.field.EncodedSecurityDescLen value) {
            setField(value);
        }

        public quickfix.field.EncodedSecurityDescLen get(
            quickfix.field.EncodedSecurityDescLen value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.EncodedSecurityDescLen getEncodedSecurityDescLen()
            throws FieldNotFound {
            quickfix.field.EncodedSecurityDescLen value = new quickfix.field.EncodedSecurityDescLen();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.EncodedSecurityDescLen field) {
            return isSetField(field);
        }

        public boolean isSetEncodedSecurityDescLen() {
            return isSetField(350);
        }

        public void set(quickfix.field.EncodedSecurityDesc value) {
            setField(value);
        }

        public quickfix.field.EncodedSecurityDesc get(
            quickfix.field.EncodedSecurityDesc value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.EncodedSecurityDesc getEncodedSecurityDesc()
            throws FieldNotFound {
            quickfix.field.EncodedSecurityDesc value = new quickfix.field.EncodedSecurityDesc();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.EncodedSecurityDesc field) {
            return isSetField(field);
        }

        public boolean isSetEncodedSecurityDesc() {
            return isSetField(351);
        }

        public void set(quickfix.field.PrevClosePx value) {
            setField(value);
        }

        public quickfix.field.PrevClosePx get(quickfix.field.PrevClosePx value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.PrevClosePx getPrevClosePx()
            throws FieldNotFound {
            quickfix.field.PrevClosePx value = new quickfix.field.PrevClosePx();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.PrevClosePx field) {
            return isSetField(field);
        }

        public boolean isSetPrevClosePx() {
            return isSetField(140);
        }

        public void set(quickfix.field.Side value) {
            setField(value);
        }

        public quickfix.field.Side get(quickfix.field.Side value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.Side getSide() throws FieldNotFound {
            quickfix.field.Side value = new quickfix.field.Side();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.Side field) {
            return isSetField(field);
        }

        public boolean isSetSide() {
            return isSetField(54);
        }

        public void set(quickfix.field.SideValueInd value) {
            setField(value);
        }

        public quickfix.field.SideValueInd get(
            quickfix.field.SideValueInd value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.SideValueInd getSideValueInd()
            throws FieldNotFound {
            quickfix.field.SideValueInd value = new quickfix.field.SideValueInd();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.SideValueInd field) {
            return isSetField(field);
        }

        public boolean isSetSideValueInd() {
            return isSetField(401);
        }

        public void set(quickfix.field.LocateReqd value) {
            setField(value);
        }

        public quickfix.field.LocateReqd get(quickfix.field.LocateReqd value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.LocateReqd getLocateReqd()
            throws FieldNotFound {
            quickfix.field.LocateReqd value = new quickfix.field.LocateReqd();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.LocateReqd field) {
            return isSetField(field);
        }

        public boolean isSetLocateReqd() {
            return isSetField(114);
        }

        public void set(quickfix.field.TransactTime value) {
            setField(value);
        }

        public quickfix.field.TransactTime get(
            quickfix.field.TransactTime value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.TransactTime getTransactTime()
            throws FieldNotFound {
            quickfix.field.TransactTime value = new quickfix.field.TransactTime();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.TransactTime field) {
            return isSetField(field);
        }

        public boolean isSetTransactTime() {
            return isSetField(60);
        }

        public void set(quickfix.field.OrderQty value) {
            setField(value);
        }

        public quickfix.field.OrderQty get(quickfix.field.OrderQty value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.OrderQty getOrderQty() throws FieldNotFound {
            quickfix.field.OrderQty value = new quickfix.field.OrderQty();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.OrderQty field) {
            return isSetField(field);
        }

        public boolean isSetOrderQty() {
            return isSetField(38);
        }

        public void set(quickfix.field.CashOrderQty value) {
            setField(value);
        }

        public quickfix.field.CashOrderQty get(
            quickfix.field.CashOrderQty value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.CashOrderQty getCashOrderQty()
            throws FieldNotFound {
            quickfix.field.CashOrderQty value = new quickfix.field.CashOrderQty();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.CashOrderQty field) {
            return isSetField(field);
        }

        public boolean isSetCashOrderQty() {
            return isSetField(152);
        }

        public void set(quickfix.field.OrdType value) {
            setField(value);
        }

        public quickfix.field.OrdType get(quickfix.field.OrdType value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.OrdType getOrdType() throws FieldNotFound {
            quickfix.field.OrdType value = new quickfix.field.OrdType();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.OrdType field) {
            return isSetField(field);
        }

        public boolean isSetOrdType() {
            return isSetField(40);
        }

        public void set(quickfix.field.Price value) {
            setField(value);
        }

        public quickfix.field.Price get(quickfix.field.Price value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.Price getPrice() throws FieldNotFound {
            quickfix.field.Price value = new quickfix.field.Price();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.Price field) {
            return isSetField(field);
        }

        public boolean isSetPrice() {
            return isSetField(44);
        }

        public void set(quickfix.field.StopPx value) {
            setField(value);
        }

        public quickfix.field.StopPx get(quickfix.field.StopPx value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.StopPx getStopPx() throws FieldNotFound {
            quickfix.field.StopPx value = new quickfix.field.StopPx();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.StopPx field) {
            return isSetField(field);
        }

        public boolean isSetStopPx() {
            return isSetField(99);
        }

        public void set(quickfix.field.Currency value) {
            setField(value);
        }

        public quickfix.field.Currency get(quickfix.field.Currency value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.Currency getCurrency() throws FieldNotFound {
            quickfix.field.Currency value = new quickfix.field.Currency();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.Currency field) {
            return isSetField(field);
        }

        public boolean isSetCurrency() {
            return isSetField(15);
        }

        public void set(quickfix.field.ComplianceID value) {
            setField(value);
        }

        public quickfix.field.ComplianceID get(
            quickfix.field.ComplianceID value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.ComplianceID getComplianceID()
            throws FieldNotFound {
            quickfix.field.ComplianceID value = new quickfix.field.ComplianceID();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.ComplianceID field) {
            return isSetField(field);
        }

        public boolean isSetComplianceID() {
            return isSetField(376);
        }

        public void set(quickfix.field.SolicitedFlag value) {
            setField(value);
        }

        public quickfix.field.SolicitedFlag get(
            quickfix.field.SolicitedFlag value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.SolicitedFlag getSolicitedFlag()
            throws FieldNotFound {
            quickfix.field.SolicitedFlag value = new quickfix.field.SolicitedFlag();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.SolicitedFlag field) {
            return isSetField(field);
        }

        public boolean isSetSolicitedFlag() {
            return isSetField(377);
        }

        public void set(quickfix.field.IOIid value) {
            setField(value);
        }

        public quickfix.field.IOIid get(quickfix.field.IOIid value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.IOIid getIOIid() throws FieldNotFound {
            quickfix.field.IOIid value = new quickfix.field.IOIid();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.IOIid field) {
            return isSetField(field);
        }

        public boolean isSetIOIid() {
            return isSetField(23);
        }

        public void set(quickfix.field.QuoteID value) {
            setField(value);
        }

        public quickfix.field.QuoteID get(quickfix.field.QuoteID value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.QuoteID getQuoteID() throws FieldNotFound {
            quickfix.field.QuoteID value = new quickfix.field.QuoteID();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.QuoteID field) {
            return isSetField(field);
        }

        public boolean isSetQuoteID() {
            return isSetField(117);
        }

        public void set(quickfix.field.TimeInForce value) {
            setField(value);
        }

        public quickfix.field.TimeInForce get(quickfix.field.TimeInForce value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.TimeInForce getTimeInForce()
            throws FieldNotFound {
            quickfix.field.TimeInForce value = new quickfix.field.TimeInForce();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.TimeInForce field) {
            return isSetField(field);
        }

        public boolean isSetTimeInForce() {
            return isSetField(59);
        }

        public void set(quickfix.field.EffectiveTime value) {
            setField(value);
        }

        public quickfix.field.EffectiveTime get(
            quickfix.field.EffectiveTime value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.EffectiveTime getEffectiveTime()
            throws FieldNotFound {
            quickfix.field.EffectiveTime value = new quickfix.field.EffectiveTime();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.EffectiveTime field) {
            return isSetField(field);
        }

        public boolean isSetEffectiveTime() {
            return isSetField(168);
        }

        public void set(quickfix.field.ExpireDate value) {
            setField(value);
        }

        public quickfix.field.ExpireDate get(quickfix.field.ExpireDate value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.ExpireDate getExpireDate()
            throws FieldNotFound {
            quickfix.field.ExpireDate value = new quickfix.field.ExpireDate();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.ExpireDate field) {
            return isSetField(field);
        }

        public boolean isSetExpireDate() {
            return isSetField(432);
        }

        public void set(quickfix.field.ExpireTime value) {
            setField(value);
        }

        public quickfix.field.ExpireTime get(quickfix.field.ExpireTime value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.ExpireTime getExpireTime()
            throws FieldNotFound {
            quickfix.field.ExpireTime value = new quickfix.field.ExpireTime();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.ExpireTime field) {
            return isSetField(field);
        }

        public boolean isSetExpireTime() {
            return isSetField(126);
        }

        public void set(quickfix.field.GTBookingInst value) {
            setField(value);
        }

        public quickfix.field.GTBookingInst get(
            quickfix.field.GTBookingInst value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.GTBookingInst getGTBookingInst()
            throws FieldNotFound {
            quickfix.field.GTBookingInst value = new quickfix.field.GTBookingInst();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.GTBookingInst field) {
            return isSetField(field);
        }

        public boolean isSetGTBookingInst() {
            return isSetField(427);
        }

        public void set(quickfix.field.Commission value) {
            setField(value);
        }

        public quickfix.field.Commission get(quickfix.field.Commission value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.Commission getCommission()
            throws FieldNotFound {
            quickfix.field.Commission value = new quickfix.field.Commission();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.Commission field) {
            return isSetField(field);
        }

        public boolean isSetCommission() {
            return isSetField(12);
        }

        public void set(quickfix.field.CommType value) {
            setField(value);
        }

        public quickfix.field.CommType get(quickfix.field.CommType value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.CommType getCommType() throws FieldNotFound {
            quickfix.field.CommType value = new quickfix.field.CommType();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.CommType field) {
            return isSetField(field);
        }

        public boolean isSetCommType() {
            return isSetField(13);
        }

        public void set(quickfix.field.Rule80A value) {
            setField(value);
        }

        public quickfix.field.Rule80A get(quickfix.field.Rule80A value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.Rule80A getRule80A() throws FieldNotFound {
            quickfix.field.Rule80A value = new quickfix.field.Rule80A();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.Rule80A field) {
            return isSetField(field);
        }

        public boolean isSetRule80A() {
            return isSetField(47);
        }

        public void set(quickfix.field.ForexReq value) {
            setField(value);
        }

        public quickfix.field.ForexReq get(quickfix.field.ForexReq value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.ForexReq getForexReq() throws FieldNotFound {
            quickfix.field.ForexReq value = new quickfix.field.ForexReq();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.ForexReq field) {
            return isSetField(field);
        }

        public boolean isSetForexReq() {
            return isSetField(121);
        }

        public void set(quickfix.field.SettlCurrency value) {
            setField(value);
        }

        public quickfix.field.SettlCurrency get(
            quickfix.field.SettlCurrency value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.SettlCurrency getSettlCurrency()
            throws FieldNotFound {
            quickfix.field.SettlCurrency value = new quickfix.field.SettlCurrency();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.SettlCurrency field) {
            return isSetField(field);
        }

        public boolean isSetSettlCurrency() {
            return isSetField(120);
        }

        public void set(quickfix.field.Text value) {
            setField(value);
        }

        public quickfix.field.Text get(quickfix.field.Text value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.Text getText() throws FieldNotFound {
            quickfix.field.Text value = new quickfix.field.Text();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.Text field) {
            return isSetField(field);
        }

        public boolean isSetText() {
            return isSetField(58);
        }

        public void set(quickfix.field.EncodedTextLen value) {
            setField(value);
        }

        public quickfix.field.EncodedTextLen get(
            quickfix.field.EncodedTextLen value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.EncodedTextLen getEncodedTextLen()
            throws FieldNotFound {
            quickfix.field.EncodedTextLen value = new quickfix.field.EncodedTextLen();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.EncodedTextLen field) {
            return isSetField(field);
        }

        public boolean isSetEncodedTextLen() {
            return isSetField(354);
        }

        public void set(quickfix.field.EncodedText value) {
            setField(value);
        }

        public quickfix.field.EncodedText get(quickfix.field.EncodedText value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.EncodedText getEncodedText()
            throws FieldNotFound {
            quickfix.field.EncodedText value = new quickfix.field.EncodedText();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.EncodedText field) {
            return isSetField(field);
        }

        public boolean isSetEncodedText() {
            return isSetField(355);
        }

        public void set(quickfix.field.FutSettDate2 value) {
            setField(value);
        }

        public quickfix.field.FutSettDate2 get(
            quickfix.field.FutSettDate2 value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.FutSettDate2 getFutSettDate2()
            throws FieldNotFound {
            quickfix.field.FutSettDate2 value = new quickfix.field.FutSettDate2();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.FutSettDate2 field) {
            return isSetField(field);
        }

        public boolean isSetFutSettDate2() {
            return isSetField(193);
        }

        public void set(quickfix.field.OrderQty2 value) {
            setField(value);
        }

        public quickfix.field.OrderQty2 get(quickfix.field.OrderQty2 value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.OrderQty2 getOrderQty2()
            throws FieldNotFound {
            quickfix.field.OrderQty2 value = new quickfix.field.OrderQty2();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.OrderQty2 field) {
            return isSetField(field);
        }

        public boolean isSetOrderQty2() {
            return isSetField(192);
        }

        public void set(quickfix.field.OpenClose value) {
            setField(value);
        }

        public quickfix.field.OpenClose get(quickfix.field.OpenClose value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.OpenClose getOpenClose()
            throws FieldNotFound {
            quickfix.field.OpenClose value = new quickfix.field.OpenClose();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.OpenClose field) {
            return isSetField(field);
        }

        public boolean isSetOpenClose() {
            return isSetField(77);
        }

        public void set(quickfix.field.CoveredOrUncovered value) {
            setField(value);
        }

        public quickfix.field.CoveredOrUncovered get(
            quickfix.field.CoveredOrUncovered value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.CoveredOrUncovered getCoveredOrUncovered()
            throws FieldNotFound {
            quickfix.field.CoveredOrUncovered value = new quickfix.field.CoveredOrUncovered();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.CoveredOrUncovered field) {
            return isSetField(field);
        }

        public boolean isSetCoveredOrUncovered() {
            return isSetField(203);
        }

        public void set(quickfix.field.CustomerOrFirm value) {
            setField(value);
        }

        public quickfix.field.CustomerOrFirm get(
            quickfix.field.CustomerOrFirm value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.CustomerOrFirm getCustomerOrFirm()
            throws FieldNotFound {
            quickfix.field.CustomerOrFirm value = new quickfix.field.CustomerOrFirm();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.CustomerOrFirm field) {
            return isSetField(field);
        }

        public boolean isSetCustomerOrFirm() {
            return isSetField(204);
        }

        public void set(quickfix.field.MaxShow value) {
            setField(value);
        }

        public quickfix.field.MaxShow get(quickfix.field.MaxShow value)
            throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.MaxShow getMaxShow() throws FieldNotFound {
            quickfix.field.MaxShow value = new quickfix.field.MaxShow();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.MaxShow field) {
            return isSetField(field);
        }

        public boolean isSetMaxShow() {
            return isSetField(210);
        }

        public void set(quickfix.field.PegDifference value) {
            setField(value);
        }

        public quickfix.field.PegDifference get(
            quickfix.field.PegDifference value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.PegDifference getPegDifference()
            throws FieldNotFound {
            quickfix.field.PegDifference value = new quickfix.field.PegDifference();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.PegDifference field) {
            return isSetField(field);
        }

        public boolean isSetPegDifference() {
            return isSetField(211);
        }

        public void set(quickfix.field.DiscretionInst value) {
            setField(value);
        }

        public quickfix.field.DiscretionInst get(
            quickfix.field.DiscretionInst value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.DiscretionInst getDiscretionInst()
            throws FieldNotFound {
            quickfix.field.DiscretionInst value = new quickfix.field.DiscretionInst();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.DiscretionInst field) {
            return isSetField(field);
        }

        public boolean isSetDiscretionInst() {
            return isSetField(388);
        }

        public void set(quickfix.field.DiscretionOffset value) {
            setField(value);
        }

        public quickfix.field.DiscretionOffset get(
            quickfix.field.DiscretionOffset value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.DiscretionOffset getDiscretionOffset()
            throws FieldNotFound {
            quickfix.field.DiscretionOffset value = new quickfix.field.DiscretionOffset();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.DiscretionOffset field) {
            return isSetField(field);
        }

        public boolean isSetDiscretionOffset() {
            return isSetField(389);
        }

        public void set(quickfix.field.ClearingFirm value) {
            setField(value);
        }

        public quickfix.field.ClearingFirm get(
            quickfix.field.ClearingFirm value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.ClearingFirm getClearingFirm()
            throws FieldNotFound {
            quickfix.field.ClearingFirm value = new quickfix.field.ClearingFirm();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.ClearingFirm field) {
            return isSetField(field);
        }

        public boolean isSetClearingFirm() {
            return isSetField(439);
        }

        public void set(quickfix.field.ClearingAccount value) {
            setField(value);
        }

        public quickfix.field.ClearingAccount get(
            quickfix.field.ClearingAccount value) throws FieldNotFound {
            getField(value);

            return value;
        }

        public quickfix.field.ClearingAccount getClearingAccount()
            throws FieldNotFound {
            quickfix.field.ClearingAccount value = new quickfix.field.ClearingAccount();
            getField(value);

            return value;
        }

        public boolean isSet(quickfix.field.ClearingAccount field) {
            return isSetField(field);
        }

        public boolean isSetClearingAccount() {
            return isSetField(440);
        }

        public static class NoAllocs extends Group {
            static final long serialVersionUID = 20050617;

            public NoAllocs() {
                super(78, 79, new int[] { 79, 80, 0 });
            }

            public void set(quickfix.field.AllocAccount value) {
                setField(value);
            }

            public quickfix.field.AllocAccount get(
                quickfix.field.AllocAccount value) throws FieldNotFound {
                getField(value);

                return value;
            }

            public quickfix.field.AllocAccount getAllocAccount()
                throws FieldNotFound {
                quickfix.field.AllocAccount value = new quickfix.field.AllocAccount();
                getField(value);

                return value;
            }

            public boolean isSet(quickfix.field.AllocAccount field) {
                return isSetField(field);
            }

            public boolean isSetAllocAccount() {
                return isSetField(79);
            }

            public void set(quickfix.field.AllocShares value) {
                setField(value);
            }

            public quickfix.field.AllocShares get(
                quickfix.field.AllocShares value) throws FieldNotFound {
                getField(value);

                return value;
            }

            public quickfix.field.AllocShares getAllocShares()
                throws FieldNotFound {
                quickfix.field.AllocShares value = new quickfix.field.AllocShares();
                getField(value);

                return value;
            }

            public boolean isSet(quickfix.field.AllocShares field) {
                return isSetField(field);
            }

            public boolean isSetAllocShares() {
                return isSetField(80);
            }
        }

        public static class NoTradingSessions extends Group {
            static final long serialVersionUID = 20050617;

            public NoTradingSessions() {
                super(386, 336, new int[] { 336, 0 });
            }

            public void set(quickfix.field.TradingSessionID value) {
                setField(value);
            }

            public quickfix.field.TradingSessionID get(
                quickfix.field.TradingSessionID value)
                throws FieldNotFound {
                getField(value);

                return value;
            }

            public quickfix.field.TradingSessionID getTradingSessionID()
                throws FieldNotFound {
                quickfix.field.TradingSessionID value = new quickfix.field.TradingSessionID();
                getField(value);

                return value;
            }

            public boolean isSet(quickfix.field.TradingSessionID field) {
                return isSetField(field);
            }

            public boolean isSetTradingSessionID() {
                return isSetField(336);
            }
        }
    }
}
